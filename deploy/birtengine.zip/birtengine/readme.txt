copy the follow libs from the viewer WEB-INF to the local lib

chart-engine.jar
common.jar
commons-cli-1.0.jar
commons-codec-1.3.jar
core.jar
dte.jar
ecore.jar
ecore.resources.jar
ecore.xmi.jar
engine.jar
js.jar
model.jar
oda.jar
Tidy.jar


set 
config.setEngineHome( "c:\\eclipse3.1\\eclipse\\plugins\\org.eclipse.birt.report.viewer_1.0.1\\birt" );
in RunReport.java
to your install location

run the following command to test
ant run -Dreport=runreport.rptdesign -Dformat=-p