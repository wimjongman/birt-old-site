package org.eclipse.birt.examples.rcpengine;

import java.util.Properties;

public class SimpleProperties {
	public static Properties getProperties() {
		Properties props = new Properties();
		props.put("First Key", "First Value");
		props.put("Second Key", "Second Value");
		props.put("Third Key", "Third Value");
		props.put("Fourth Key", "Fourth Value");
		return props;
	}
}