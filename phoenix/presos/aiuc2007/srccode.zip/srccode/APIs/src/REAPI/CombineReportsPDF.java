package REAPI;



import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.PDFRenderOption;

import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;



import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfCopyFields;





public class CombineReportsPDF {

	public void concat(byte[] ba1, byte[] ba2, String outpath){

		try{
			PdfReader rd1 = new PdfReader( ba1 );
			PdfReader rd2 = new PdfReader( ba2 );
			PdfCopyFields cpy = new PdfCopyFields( new FileOutputStream( outpath ));
			cpy.addDocument(rd1);
			cpy.addDocument(rd2);
			cpy.close();

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public void runReport() throws EngineException
	{

		IReportEngine engine=null;
		EngineConfig config = null;

		try{

			config = new EngineConfig( );			
			config.setBIRTHome("C:\\birt\\birt-runtime-2_2_0\\birt-runtime-2_2_0\\ReportEngine");
			config.setLogConfig(null, Level.OFF);
			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
		}catch( Exception ex){
			ex.printStackTrace();
		}

		IReportRunnable design, design2 = null;
		//Open the report design
		design = engine.openReportDesign("Reports/TopNPercent.rptdesign"); 
		design2 = engine.openReportDesign("Reports/TopSellingProducts.rptdesign"); 



		//Create task to run and render the report,
		IRunAndRenderTask task = engine.createRunAndRenderTask(design); 		
		task.setParameterValue("Top Percentage", (new Integer(3)));
		task.setParameterValue("Top Count", (new Integer(5)));
		task.validateParameters();

		PDFRenderOption options = new PDFRenderOption();
		ByteArrayOutputStream fso= new ByteArrayOutputStream();
		ByteArrayOutputStream fso2= new ByteArrayOutputStream();
		options.setOutputStream(fso);
		options.setOutputFormat("pdf");

		task.setRenderOption(options);
		task.run();
		task.close();

		//Create task to run and render the report,
		task = engine.createRunAndRenderTask(design2); 


		options.setOutputStream(fso2);		
		options.setOutputFormat("pdf");

		task.setRenderOption(options);		


		task.run();
		task.close();

		concat( fso.toByteArray(), fso2.toByteArray(), "output/resample/Combined.pdf");

		engine.destroy();
		Platform.shutdown();
		System.out.println("Finished");
	}	


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{

			CombineReportsPDF ex = new CombineReportsPDF( );
			ex.runReport();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}



}


