package REAPI;


import java.util.HashMap;
import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLActionHandler;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.HTMLServerImageHandler;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IReportDocument;
import org.eclipse.birt.core.archive.*;

import org.eclipse.birt.report.engine.api.IRenderTask;
import org.eclipse.birt.report.engine.api.IRenderOption;
import org.eclipse.birt.report.engine.api.RenderOption;
import org.eclipse.birt.report.engine.api.IHTMLRenderOption;
import org.eclipse.birt.report.engine.api.IPDFRenderOption;
import java.io.ByteArrayOutputStream;

import org.eclipse.birt.report.engine.api.IPageHandler;
import org.eclipse.birt.report.engine.api.IReportDocumentInfo;
import java.util.ArrayList;



import org.eclipse.birt.report.engine.api.IRunTask;




public class ProgressiveView
{

 static final String REPORT_DESIGN_RESOURCE = "org/eclipse/birt/report/engine/api/progressive_viewing.rptdesign";
 // static final String REPORT_DESIGN_RESOURCE =
 // "org/eclipse/birt/report/engine/api/empty_page.rptdesign";
 static final String REPORT_DESIGN = "progressive_viewing.rptdesign";
 static final String REPORT_DOCUMENT = "./reportdocument.folder/";

 protected IReportEngine engine;
protected FileArchiveWriter fw;


 /**
  * new a thread to start the run task. In the run task, we register a
  * PageHander to triger the render task.
  */
 public void testProgressiveViewing( )
 {
 
	  
	  
	  

		EngineConfig config = null;
		try{
	
			config = new EngineConfig( );			
			config.setBIRTHome("C:\\birt\\birt-runtime-2_2_0\\birt-runtime-2_2_0\\ReportEngine");
			config.setLogConfig(null, Level.OFF);
			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
		}catch( Exception ex){
			ex.printStackTrace();
		}	  
	  
	  
		  try
		  {
			   
	  
   // open the report runnable to execute.
   IReportRunnable report = engine.openReportDesign( "Reports/customers.rptdesign" );
   // create an IRunTask
   IRunTask task = engine.createRunTask( report );
   // execute the report to create the report document.
   task.setPageHandler( new RenderTaskTrigger( ) );
   //fw = new FileArchiveWriter("c:/temp/progress/myrptdoc.rptdocument");
   task.run( "c:/temp/progress/myrptdoc.rptdocument" );
   //task.run(fw );
   // close the task, release the resource.
   task.close( );

   for ( int i = 0; i < pages.size( ); i++ )
   {
    PageContent pageContent = (PageContent) pages.get( i );

    IReportDocument reportDocument = engine
      .openReportDocument( "c:/temp/progress/myrptdoc.rptdocument" );
    IRenderTask renderTask = engine
      .createRenderTask( reportDocument );
    HTMLRenderOption options = new HTMLRenderOption( );
    options.setOutputFormat( "html" );
    ByteArrayOutputStream ostream = new ByteArrayOutputStream( );
    options.setOutputStream( ostream );
    renderTask.setRenderOption( options );
    renderTask.setPageNumber( pageContent.page );
    renderTask.render( );
    renderTask.close( );
    reportDocument.close( );
    String content = ostream.toString( "utf-8" );


   }
   engine.destroy();
   Platform.shutdown();
   System.out.println("Finsihed");
  }
  catch ( Exception ex )
  {
   ex.printStackTrace( );

  };

 }

 class PageContent
 {

  PageContent( int page, String content )
  {
   this.page = page;
   this.content = content;
  }
  int page;
  String content;
 }

 ArrayList pages = new ArrayList( );

 class RenderTaskTrigger implements IPageHandler
 {

  IRenderTask renderTask;

  RenderTaskTrigger( )
  {
  }

  public void onPage( int pageNumber, boolean checkpoint,
    IReportDocumentInfo doc )
  {
   try
   {
	//if( pageNumber == 1)return;
	//fw.flush();
	if( doc.isComplete()){
		System.out.println("DocumentFinished");
	}
    if ( checkpoint == true )
    {
     
     IReportDocument reportDocument = engine.openReportDocument("c:/temp/progress/myrptdoc.rptdocument.tmpfolder");
     //IReportDocument reportDocument = engine.openReportDocument( "output/resample/customers.rptdocument" );
     renderTask = engine.createRenderTask( reportDocument );
     HTMLRenderOption options = new HTMLRenderOption( );
     options.setOutputFormat( "html" );
     ByteArrayOutputStream ostream = new ByteArrayOutputStream( );
     options.setOutputStream( ostream );
     renderTask.setRenderOption( options );
     renderTask.setPageNumber( pageNumber );
     renderTask.render( );
     renderTask.close( );
     reportDocument.close( );
     String content = ostream.toString( "utf-8" );
     System.out.println( pageNumber );
     System.out.println( content );
     pages.add( new PageContent( pageNumber, content ) );
    }
   }
   catch ( Exception ex )
   {
    ex.printStackTrace( );

   }
  }
 }
 
	public static void main(String[] args) {
		try
		{

			ProgressiveView ex = new ProgressiveView( );
			ex.testProgressiveViewing();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}

}

