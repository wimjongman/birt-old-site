package REAPI;



import java.util.HashMap;
import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLActionHandler;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.HTMLServerImageHandler;
import org.eclipse.birt.report.engine.api.HTMLCompleteImageHandler;

import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import org.eclipse.birt.report.engine.api.RenderOption;
import java.io.FileOutputStream;
import java.io.File;



public class CombineReports {

	public void runReport() throws EngineException
	{

		IReportEngine engine=null;
		EngineConfig config = null;

		try{
	
			config = new EngineConfig( );			
			config.setBIRTHome("C:\\birt\\birt-runtime-2_2_0\\birt-runtime-2_2_0\\ReportEngine");
			config.setLogConfig(null, Level.OFF);
			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
		}catch( Exception ex){
			ex.printStackTrace();
		}

		IReportRunnable design, design2 = null;
		//Open the report design
		design = engine.openReportDesign("Reports/TopNPercent.rptdesign"); 
		design2 = engine.openReportDesign("Reports/TopSellingProducts.rptdesign"); 
	


		//Create task to run and render the report,
		IRunAndRenderTask task = engine.createRunAndRenderTask(design); 		
		task.setParameterValue("Top Percentage", (new Integer(3)));
		task.setParameterValue("Top Count", (new Integer(5)));
		task.validateParameters();
				
		HTMLRenderOption options = new HTMLRenderOption();
		FileOutputStream fso=null, fso2=null;
		try{
			fso = new FileOutputStream(new File("output/resample/Combined.html"), true);
		}catch (Exception e){
			e.printStackTrace();
		}
		options.setOutputStream(fso);
		options.setEmbeddable(true);
		options.setOutputFormat("html");
		options.setImageDirectory("images");
		
		//ImageHandlerTest
		//options.setImageHandler(new MyImageHandler());
		//options.setImageHandler(new HTMLServerImageHandler());
		options.setImageHandler(new HTMLCompleteImageHandler());
		task.setRenderOption(options);
		task.run();
		

		//Create task to run and render the report,
		task = engine.createRunAndRenderTask(design2); 
		
		
		try{
			fso.flush();
			fso.close();
			fso2 = new FileOutputStream(new File("output/resample/Combined.html"), true);
		}catch (Exception e){
			e.printStackTrace();
		}
		options.setOutputStream(fso2);		
		task.setRenderOption(options);		
		
		
		task.run();
		task.close();
		try{
			fso2.flush();
			fso2.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		engine.destroy();
		Platform.shutdown();
		System.out.println("Finished");
	}	


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{

			CombineReports ex = new CombineReports( );
			ex.runReport();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	private class CancelReport extends Thread
	{
		private IRunAndRenderTask rTask;
		public CancelReport( String threadName, IRunAndRenderTask task){
			super(threadName);
			rTask = task;
			
		}
		public void run()
		{
			try{
				Thread.currentThread().sleep( 100 );
				rTask.cancel();
				System.out.println("######Report Cancelled#######");
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	
}


