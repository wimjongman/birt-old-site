package myTest;

import java.util.Random;

import org.eclipse.birt.report.engine.api.script.IUpdatableDataSetRow;
import org.eclipse.birt.report.engine.api.script.ScriptException;
import org.eclipse.birt.report.engine.api.script.eventadapter.ScriptedDataSetEventAdapter;
import org.eclipse.birt.report.engine.api.script.instance.IDataSetInstance;

public class MyTestEventAdapter extends ScriptedDataSetEventAdapter {

	private int counter = 0;
	private Random rand;
	
	public MyTestEventAdapter() {
		super();
		counter = 0;
		rand = new Random();
	}

	public boolean fetch(IDataSetInstance dsi, IUpdatableDataSetRow update)
	{
		if (counter > 3)
			return false;
		
		else
		{
			try {
				update.setColumnValue("1", new Integer(rand.nextInt(20)));
				update.setColumnValue("2", new Integer(rand.nextInt(20)));
				update.setColumnValue("3", new Integer(rand.nextInt(20)));
			} catch (ScriptException e) {
				e.printStackTrace();
				counter = 6;
			}
				
			counter++;
				
			return true;
		}
	}
}
