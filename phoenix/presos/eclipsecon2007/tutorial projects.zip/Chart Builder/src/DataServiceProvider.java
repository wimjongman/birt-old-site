

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.birt.chart.model.attribute.DataType;
import org.eclipse.birt.chart.ui.swt.interfaces.IDataServiceProvider;
import org.eclipse.jface.window.Window;

/**
 * Provides a basic implementation for simulated data service. Used in launcher.
 * 
 */
public class DataServiceProvider implements IDataServiceProvider
{

	private transient String sDataSetName = null; //$NON-NLS-1$
	
	private static final int ROW_COUNT = 6;
	private ResultSet resultSet = null;
	private ResultSetMetaData meta;
	private Map tables;
	public DataServiceProvider() {
		tables = new HashMap();
		tables.put("Census","Census");
		tables.put("Product Sales", "SampleData");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getAllDataSets()
	 */
	public String[] getAllDataSets( )
	{
		return (String[])tables.keySet().toArray( new String[]{});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getCurrentDataSet()
	 */
	public String getBoundDataSet( )
	{
		// TODO Auto-generated method stub
		return sDataSetName;
	}

	public String getReportDataSet( )
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getPreviewHeader(java.lang.String)
	 */
	public String[] getPreviewHeader() {
		String columns[] = null;
		try {
			columns = new String[meta.getColumnCount()];
			for (int i = 0; i < meta.getColumnCount() ; i++) {
				columns[i] = meta.getColumnName(i+1);
			}
		} catch (SQLException e) {
		}
		return columns;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getPreviewData(java.lang.String)
	 */
	public List getPreviewData( )
	{
		List list = new ArrayList( );
		try {
		resultSet.first();
		for ( int rowNum = 0; rowNum < ROW_COUNT; rowNum++ )
		{
			String[] columns = new String[meta.getColumnCount()];
			for ( int i = 0; i < columns.length ; i++ )
			{
				columns[i] = resultSet.getObject(i+1).toString();
			}
			list.add( columns );
			resultSet.next();
		}
		}catch (SQLException e )
		{}
		return list;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#setContext(java.lang.Object)
	 */
	public void setContext( Object context )
	{
		// this.context = context;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#setDataSet(java.lang.String)
	 */
	public void setDataSet( String datasetName )
	{
		this.sDataSetName = datasetName;
		
		Statement stmt = null;
	      

	      try {
	         
	         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); 

	         Connection conn = DriverManager.getConnection(
	            "jdbc:odbc:chartdata" );

	         stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
	         stmt.setMaxRows(ROW_COUNT);
	         resultSet = stmt.executeQuery(
	            "SELECT * from " + 
	            (String)tables.get(datasetName));
	     	
			meta  = resultSet.getMetaData();
			

	      } catch (SQLException se) {
	       
	      } catch (Exception e) {
	         
	      }
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#invoke(java.lang.String)
	 */
	public int invoke( int command )
	{
		return Window.CANCEL;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getAllStyles()
	 */
	public String[] getAllStyles( )
	{
		return new String[]{};
	}

	public String[] getAllStyleDisplayNames( )
	{
		return getAllStyles( );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#getCurrentStyle()
	 */
	public String getCurrentStyle( )
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.ui.interfaces.IDataServiceProvider#setStyle(java.lang.String)
	 */
	public void setStyle( String styleName )
	{
		// TODO Auto-generated method stub
	}

	public Object[] getDataForColumns(String[] sExpressions, int iMaxRecords,
			boolean byRow)
	{
		Object[] array = new Object[sExpressions.length];
		// Always provide data by column
		try
		{

			for (int i = 0; i < sExpressions.length; i++)// a column
			{
				resultSet.first();
				Object[] innerArray = new Object[ROW_COUNT];// a row
				for (int j = 0; j < ROW_COUNT; j++)
				{
					
					String str = sExpressions[i];

					innerArray[j] = resultSet.getObject(str);
					resultSet.next();
					
				}
				array[i] = innerArray;
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return array;
	}

	public void dispose( )
	{
		// TODO Auto-generated method stub

	}

	public boolean isLivePreviewEnabled( )
	{
		return true;
	}

	public boolean isInvokingSupported( )
	{
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.birt.chart.ui.swt.interfaces.IDataServiceProvider#getDataType(java.lang.String)
	 */
	public DataType getDataType(String expression)
	{
		if ( meta == null )
			return null;
		try
		{
			for (int col = 1; col < meta.getColumnCount()+1; col++)
			{
				if (meta.getColumnName(col).equalsIgnoreCase(expression))
				{
					switch (meta.getColumnType(col))
					{
					case Types.NUMERIC:
					case Types.DECIMAL:
					case Types.INTEGER:
					case Types.DOUBLE:
					case Types.FLOAT:
					case Types.SMALLINT:
						return DataType.NUMERIC_LITERAL;

					case Types.VARCHAR:
					case Types.CHAR:
					case Types.LONGVARCHAR:
						return DataType.TEXT_LITERAL;

					}
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
