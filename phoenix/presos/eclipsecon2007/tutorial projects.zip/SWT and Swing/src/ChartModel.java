import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.eclipse.birt.chart.factory.Generator;
import org.eclipse.birt.chart.factory.RunTimeContext;
import org.eclipse.birt.chart.model.Chart;
import org.eclipse.birt.chart.model.ChartWithoutAxes;
import org.eclipse.birt.chart.model.Serializer;
import org.eclipse.birt.chart.model.attribute.ActionType;
import org.eclipse.birt.chart.model.attribute.ActionValue;
import org.eclipse.birt.chart.model.attribute.TriggerCondition;
import org.eclipse.birt.chart.model.attribute.impl.CallBackValueImpl;
import org.eclipse.birt.chart.model.data.Action;
import org.eclipse.birt.chart.model.data.SeriesDefinition;
import org.eclipse.birt.chart.model.data.Trigger;
import org.eclipse.birt.chart.model.data.impl.ActionImpl;
import org.eclipse.birt.chart.model.data.impl.TriggerImpl;
import org.eclipse.birt.chart.model.impl.SerializerImpl;
import org.eclipse.birt.chart.model.type.PieSeries;


public class ChartModel
{
	public static Chart loadChart(String name)
	{
		Chart chart = null;

		InputStream chartFile = ChartModel.class.getResourceAsStream(name);
		Serializer serializer = SerializerImpl.instance();
		
		// Reads the chart model
		try
		{
			chart = serializer.read(  chartFile ) ;
		}
		catch ( IOException e )
		{
			e.printStackTrace();
		}

		return chart;
	}
	
	public static void bindData(Chart chart, RunTimeContext context, String query)
	{
		Statement stmt = null;
		ResultSet resultSet = null;

		try
		{

			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

			Connection conn = DriverManager
					.getConnection("jdbc:odbc:chartdata");

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

			resultSet = stmt.executeQuery(query);

			// do something with resultSet
			Generator.instance().bindData(resultSet, chart, context);

			// close the connection
			conn.close();

		} catch (SQLException se)
		{
			se.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}
	

}
