import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.eclipse.birt.chart.computation.DataPointHints;
import org.eclipse.birt.chart.device.ICallBackNotifier;
import org.eclipse.birt.chart.device.IDeviceRenderer;
import org.eclipse.birt.chart.event.WrappedStructureSource;
import org.eclipse.birt.chart.exception.ChartException;
import org.eclipse.birt.chart.factory.GeneratedChartState;
import org.eclipse.birt.chart.factory.Generator;
import org.eclipse.birt.chart.factory.RunTimeContext;
import org.eclipse.birt.chart.model.Chart;
import org.eclipse.birt.chart.model.ChartWithoutAxes;
import org.eclipse.birt.chart.model.Serializer;
import org.eclipse.birt.chart.model.attribute.ActionType;
import org.eclipse.birt.chart.model.attribute.ActionValue;
import org.eclipse.birt.chart.model.attribute.Bounds;
import org.eclipse.birt.chart.model.attribute.CallBackValue;
import org.eclipse.birt.chart.model.attribute.TriggerCondition;
import org.eclipse.birt.chart.model.attribute.impl.BoundsImpl;
import org.eclipse.birt.chart.model.attribute.impl.CallBackValueImpl;
import org.eclipse.birt.chart.model.component.Series;
import org.eclipse.birt.chart.model.data.Action;
import org.eclipse.birt.chart.model.data.SeriesDefinition;
import org.eclipse.birt.chart.model.data.Trigger;
import org.eclipse.birt.chart.model.data.impl.ActionImpl;
import org.eclipse.birt.chart.model.data.impl.TriggerImpl;
import org.eclipse.birt.chart.model.impl.SerializerImpl;
import org.eclipse.birt.chart.model.type.PieSeries;
import org.eclipse.birt.chart.util.PluginSettings;

import com.ibm.icu.util.ULocale;


public class SwingViewer extends JPanel implements ICallBackNotifier
{

	private static final long serialVersionUID = 1L;

	private boolean bNeedsGeneration = true;

	private GeneratedChartState gcs = null;

	private Chart cm = null;

	private IDeviceRenderer idr = null;

	private Map contextMap;

	private RunTimeContext context;

	private String query = "SELECT * from SampleData";
	
	/**
	 * Contructs the layout with a container for displaying chart and a control
	 * panel for selecting chart attributes.
	 * 
	 * @param args
	 */
	public static void main( String[] args )
	{
		SwingViewer viewer = new SwingViewer();
		JFrame jf = new JFrame( );
		jf.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );


		Container co = jf.getContentPane( );
		co.setLayout( new BorderLayout( ) );
		co.add( viewer, BorderLayout.CENTER );

		Dimension dScreen = Toolkit.getDefaultToolkit( ).getScreenSize( );
		Dimension dApp = new Dimension( 500, 300 );
		jf.setSize( dApp );
		jf.setLocation( ( dScreen.width - dApp.width ) / 2,
				( dScreen.height - dApp.height ) / 2 );

		jf.setVisible( true );
	}

	/**
	 * Get the connection with SWING device to render the graphics.
	 */
	SwingViewer()
	{
		contextMap = new HashMap();

		final PluginSettings ps = PluginSettings.instance();
		try
		{
			idr = ps.getDevice("dv.SWING");//$NON-NLS-1$

			// The default chart displayed in the container is the simple bar
			// chart.
			cm = ChartModel.loadChart("swingchart.xml");
			context = Generator.instance().prepare(cm, null, null,
					ULocale.getDefault());
			addInteractivity(cm, this.getClass());
			
			
		} catch (ChartException ex)
		{
			ex.printStackTrace();
		}
	}
	

	public  PieSeries getValueSeries(Chart cm)
	{
		SeriesDefinition baseSeries = (SeriesDefinition)((ChartWithoutAxes)cm).getSeriesDefinitions().get(0);
		SeriesDefinition valueSeries = (SeriesDefinition)baseSeries.getSeriesDefinitions().get(0);
		return (PieSeries)valueSeries.getSeries().get(0);
	}
	public  void addInteractivity(Chart cm, Class clazz)
	{
		
		ActionValue actionValue = CallBackValueImpl.create(clazz.getCanonicalName());
		Action action = ActionImpl.create(ActionType.CALL_BACK_LITERAL, actionValue);
		Trigger onclick = TriggerImpl.create(TriggerCondition.ONCLICK_LITERAL,action);
		getValueSeries(cm).getTriggers().add(onclick);
		
	}
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.swing.IUpdateNotifier#update()
	 */
	public void regenerateChart( )
	{
		bNeedsGeneration = true;
		repaint( );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.swing.IUpdateNotifier#update()
	 */
	public void repaintChart( )
	{
		repaint( );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.swing.IUpdateNotifier#peerInstance()
	 */
	public Object peerInstance( )
	{
		return this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.swing.IUpdateNotifier#getDesignTimeModel()
	 */
	public Chart getDesignTimeModel( )
	{
		return cm;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.IUpdateNotifier#getContext(java.lang.Object)
	 */
	public Object getContext( Object key )
	{
		return contextMap.get( key );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.IUpdateNotifier#putContext(java.lang.Object,
	 *      java.lang.Object)
	 */
	public Object putContext( Object key, Object value )
	{
		return contextMap.put( key, value );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.IUpdateNotifier#removeContext(java.lang.Object)
	 */
	public Object removeContext( Object key )
	{
		return contextMap.remove( key );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.chart.device.swing.IUpdateNotifier#getRunTimeModel()
	 */
	public Chart getRunTimeModel( )
	{
		return gcs.getChartModel( );
	}

	public void paint( Graphics g )
	{
		super.paint( g );
		
		// Bind data before rendering
		ChartModel.bindData(cm, context, query);
		
		Graphics2D g2d = (Graphics2D) g;
		idr.setProperty( IDeviceRenderer.GRAPHICS_CONTEXT, g2d );
		idr.setProperty( IDeviceRenderer.UPDATE_NOTIFIER, this );

		Dimension d = getSize( );
		Bounds bo = BoundsImpl.create( 0, 0, d.width, d.height );
		bo.scale( 72d / idr.getDisplayServer( ).getDpiResolution( ) );

		Generator gr = Generator.instance( );

		// When the update button has been pushed, build a chart offscreen.
		if ( bNeedsGeneration )
		{
			bNeedsGeneration = false;
			try
			{
				gcs = gr.build( idr.getDisplayServer( ),
						cm,
						bo,
						null,
						null,
						null );
			}
			catch ( ChartException ex )
			{
				ex.printStackTrace();
			}
		}

		// Draw the previous built chart on screen.
		try
		{
			gr.render( idr, gcs );
		}
		catch ( ChartException ex )
		{
			ex.printStackTrace();
		}
	}

	

	
	public void callback(Object event, Object source, CallBackValue value)
	{
		if (source instanceof WrappedStructureSource )
		{
			DataPointHints hint = (DataPointHints)((WrappedStructureSource)source).getSource();
			
			getValueSeries(cm).setExplosionExpression("categoryData==\""+ hint.getBaseValue()+"\"");
			//categoryData, valueData, valueSeriesName
			regenerateChart();
		}
		

	}


}
