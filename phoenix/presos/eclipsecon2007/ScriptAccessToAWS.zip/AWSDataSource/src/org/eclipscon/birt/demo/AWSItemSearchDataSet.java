/*******************************************************************************
 * Copyright (c) 2007 Actuate Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 *******************************************************************************/

package org.eclipscon.birt.demo;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.eclipse.birt.report.engine.api.script.IUpdatableDataSetRow;
import org.eclipse.birt.report.engine.api.script.ScriptException;
import org.eclipse.birt.report.engine.api.script.eventadapter.ScriptedDataSetEventAdapter;
import org.eclipse.birt.report.engine.api.script.instance.IDataSetInstance;

import com.amazon.xml.AWSECommerceService.AWSECommerceServiceLocator;
import com.amazon.xml.AWSECommerceService.AWSECommerceServicePortType;
import com.amazon.xml.AWSECommerceService.ItemSearchRequest;
import com.amazon.xml.AWSECommerceService._Item;
import com.amazon.xml.AWSECommerceService._ItemSearch;
import com.amazon.xml.AWSECommerceService._ItemSearchResponse;
import com.amazon.xml.AWSECommerceService._Items;

/**
 * Implementation of scripted data set event handler
 *
 * Subclassing ScriptedDataSetEventAdaptor is preferrable to implementating
 * IScriptedDataSetEventHandler directly. This insulates the class from future
 * changes in the interface
 */

public class AWSItemSearchDataSet extends ScriptedDataSetEventAdapter
{
	private _Item[]	items;
	private int currentIndex = 0;
	private int count;

	/**
	 * Handles data set open event
	 */
	public void open(IDataSetInstance dataSet)
	{
		super.open(dataSet);
		currentIndex = 0;
		count = 0;
		items = null;

		// Issue SOAP request
		// TODO: place your own Amazon Web Service access key ID here
		String accessKeyId = "xxxxxxxxxxxxxx";

		AWSECommerceServiceLocator locator = new AWSECommerceServiceLocator();
		AWSECommerceServicePortType service;
		try
		{
			service = locator.getAWSECommerceServicePort( );
		}
		catch (ServiceException e)
		{
			e.printStackTrace();
			return;
		}

		_ItemSearch search = new _ItemSearch();
		search.setSubscriptionId( accessKeyId );
		ItemSearchRequest request = new ItemSearchRequest();
		request.setSearchIndex("Books");
		request.setTitle("BIRT");

		search.setRequest( new ItemSearchRequest[]{ request });
		_ItemSearchResponse res;
		try
		{
			res = service.itemSearch( search );
		}
		catch (RemoteException e)
		{
			e.printStackTrace();
			return;
		}

		_Items[] itemsArray = res.getItems();
		if ( itemsArray != null && itemsArray.length > 0 )
		{
			items = res.getItems()[0].getItem();
			if ( items != null )
				count = items.length;
		}
	}

	public void close(IDataSetInstance arg0)
	{
		super.close(arg0);
	}

	public boolean fetch(IDataSetInstance dataSet, IUpdatableDataSetRow row)
	{
		if ( currentIndex >= count )
			return false;			// End of list
		_Item item = items[currentIndex];
		++currentIndex;

		String title = item.getItemAttributes().getTitle();
		String[] authorsArr = item.getItemAttributes().getAuthor();
		int count = (authorsArr != null? authorsArr.length : 0);
		String authors = "";
		if ( count > 0 )
		{
			authors = authorsArr[0];
			for ( int i = 1; i < authorsArr.length; i++)
			{
				authors +=  ", " + authorsArr[i];
			}
		}
		String url = item.getDetailPageURL();
		String publisher = item.getItemAttributes().getManufacturer();

		try
		{
			row.setColumnValue("Title", title);
			row.setColumnValue("Authors", authors );
			row.setColumnValue("URL", url);
			row.setColumnValue("Publisher", publisher);
		}
		catch (ScriptException e)
		{
			e.printStackTrace();
		}
		return true;
	}


}
