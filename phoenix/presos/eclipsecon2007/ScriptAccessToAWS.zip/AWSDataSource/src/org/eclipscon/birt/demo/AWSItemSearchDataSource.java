/*******************************************************************************
 * Copyright (c) 2007 Actuate Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 *******************************************************************************/

package org.eclipscon.birt.demo;

import org.eclipse.birt.report.engine.api.script.eventadapter.ScriptedDataSourceEventAdapter;

/**
 * Implementation of scripted data source event handler
 *
 * Subclassing ScriptedDataSourceEventAdaptor is preferrable to implementating
 * IScriptedDataSourceEventHandler directly. This insulates the class from future
 * changes in the interface
 */
public class AWSItemSearchDataSource extends ScriptedDataSourceEventAdapter
{

}
