/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package emitter_xform;

import java.util.ArrayList;
import java.util.logging.Logger;

public class XformColumn
{
	private ArrayList<String> items = new ArrayList<String>();
	private static Logger logger = Logger.getLogger(XformColumn.class.getName());

	public ArrayList<String> getItems()
	{
		logger.finest("");
		return items;
	}

	public void setItems(ArrayList<String> items)
	{
		logger.finest("");
		this.items = items;
	}
	
	public void addItem(String str){
		logger.finest("");
		items.add(str);
	}

}
