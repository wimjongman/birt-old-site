/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package emitter_xform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Logger;

import org.eclipse.birt.report.engine.emitter.XMLWriter;

/**
 * Helper class that assists in the build up of table information as a collection of columns
 * each column, will have a distinct element for each row returned by the data source
 * @author Scott Rosenbaum
 *
 */
public class XformTable
{
	private ArrayList<XformColumn> cols = new ArrayList<XformColumn>();
	private Iterator<XformColumn> colIterator;
	private static Logger logger = Logger.getLogger(XformTable.class.getName());
	
	public XformTable(int numberColumns){
		for (int i = 0; i < numberColumns; i++)
		{
			XformColumn aCol = new XformColumn();
			cols.add(aCol);
		}
	}
	
	public void addItem(String item ) {
		if (colIterator == null)
			colIterator = cols.iterator();

		if (colIterator.hasNext() == false){
			logger.severe("RAN OUT OF COLUMNS ");
		}
		
		XformColumn aCol = colIterator.next();
		aCol.addItem(item);
	}
	
	public void closeRow(){
		colIterator = null;
	}
	
	public void write(XMLWriter writer) {
		writer.openTag(XformTags.TABLE_START);
		for(XformColumn col: cols){
			writer.openTag(XformTags.ROW_START);
			for(String str : col.getItems()){
				writer.openTag(XformTags.CELL_START);
				writer.text(str);
				writer.closeTag(XformTags.CELL_START);
			}
			writer.closeTag(XformTags.ROW_START);
		}
		writer.closeTag(XformTags.TABLE_START);
	}
}
