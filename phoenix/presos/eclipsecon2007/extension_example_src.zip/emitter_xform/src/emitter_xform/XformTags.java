/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package emitter_xform;

/**
 * 
 * define all tags used in xform emitter 
 */
public class XformTags
{
  
    public static final String TABLE_START = "table" ; //$NON-NLS-1$
    public static final String ROW_START = "tr" ; //$NON-NLS-1$
    public static final String CELL_START = "td" ; //$NON-NLS-1$
    
}
