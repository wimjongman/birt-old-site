/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package emitter_xform;

import java.util.logging.Logger;

import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class XformPlugin extends Plugin
{
	public static final String PLUGIN_ID = "emitter_xform";
	private static XformPlugin plugin;
	private static Logger logger = Logger.getLogger(XformPlugin.class.getName());

	/**
	 * The constructor
	 */
	public XformPlugin() {
		logger.finest("");
		plugin = this;
	}

	public void start(BundleContext context) throws Exception
	{
		logger.finest("");
		super.start(context);
	}

	public void stop(BundleContext context) throws Exception
	{
		logger.finest("");
		plugin = null;
		super.stop(context);
	}

	public static XformPlugin getDefault()
	{
		logger.finest("");
		return plugin;
	}

}
