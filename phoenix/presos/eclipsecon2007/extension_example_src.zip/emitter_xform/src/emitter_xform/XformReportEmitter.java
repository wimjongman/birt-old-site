/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package emitter_xform;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.birt.report.engine.api.RenderOption;
import org.eclipse.birt.report.engine.content.ICellContent;
import org.eclipse.birt.report.engine.content.IDataContent;
import org.eclipse.birt.report.engine.content.ILabelContent;
import org.eclipse.birt.report.engine.content.IReportContent;
import org.eclipse.birt.report.engine.content.IRowContent;
import org.eclipse.birt.report.engine.content.ITableContent;
import org.eclipse.birt.report.engine.content.ITextContent;
import org.eclipse.birt.report.engine.emitter.ContentEmitterAdapter;
import org.eclipse.birt.report.engine.emitter.IEmitterServices;
import org.eclipse.birt.report.engine.emitter.XMLWriter;

/**
 * <code>XformReportEmitter</code> is a subclass of <code>ContentEmitterAdapter</code> 
 * that implements IContentEmitter interface to output Report ojbects to Cvs file.
 * 
 * @version $Revision: 1.00 $ $Date: 2007/02/15 09:56:13 $
 */
public class XformReportEmitter extends ContentEmitterAdapter
{

	public static final String OUTPUT_FORMAT_XFORM = "XFORM";
	protected IReportContent report;
	protected IEmitterServices emitterServices;
	protected Logger logger = Logger.getLogger(XformReportEmitter.class.getName());
	private ArrayList<XformTable> tableList = new ArrayList<XformTable>();
	private XformTable curTable;
	private String REPORT_FILE = "transformReport.html";

	public XformReportEmitter() {
		super();
		logger.finest("");
	}
	
	private OutputStream getOutputStream(){
		logger.finest("");
		OutputStream out = null;
		Object fileDescriptor = emitterServices.getOption(RenderOption.OUTPUT_FILE_NAME);
		File file = null;
		try
		{
			if (fileDescriptor != null)
			{
				file = new File(fileDescriptor.toString());
				File parent = file.getParentFile();
				if (parent != null && !parent.exists())
				{
					parent.mkdirs();
				}
				out = new BufferedOutputStream(new FileOutputStream(file));
			}
		} catch (FileNotFoundException e)
		{
			logger.log(Level.WARNING, e.getMessage(), e);
		}

		if (out == null)
		{
			Object value = emitterServices.getOption(RenderOption.OUTPUT_STREAM);
			if (value != null && value instanceof OutputStream)
			{
				out = (OutputStream) value;
			} else
			{
				try
				{

					file = new File(REPORT_FILE);
					out = new BufferedOutputStream(new FileOutputStream(file));
				} catch (FileNotFoundException e)
				{

					logger.log(Level.SEVERE, e.getMessage(), e);
				}
			}
		}
		
		return out;

	}

	public void initialize(IEmitterServices services)
	{
		logger.finest("");
		this.emitterServices = services;
	}

	public IReportContent getReport()
	{
		logger.finest("");
		return report;
	}

	public String getOutputFormat()
	{
		return OUTPUT_FORMAT_XFORM;
	}

	public void start(IReportContent report)
	{
		logger.finest(report.getDesign().getReportDesign().getFileName());
		this.report = report;
	}

	public void end(IReportContent report)
	{
		logger.finest(report.getDesign().getReportDesign().getFileName());
		OutputStream out = getOutputStream();
		XMLWriter writer = new XMLWriter();
		writer.open(out, "UTF-8");
		writer.literal("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
		
		for (XformTable xformTable : tableList)
		{
			xformTable.write(writer);
		}
		
		writer.close();
	}

	public void startTable(ITableContent table)
	{
		curTable = new XformTable(table.getColumnCount());
		logger.finest(table.getName());
	}

	public void endTable(ITableContent table)
	{
		tableList.add(curTable);
		logger.finest(table.getName());
	}

	public void startRow(IRowContent row)
	{
		logger.finest(row.getX() + ":" + row.getY());
		if (curTable == null){
			logger.severe("table not open");
			return;
		}
		curTable.closeRow();
	}

	public void endRow(IRowContent row)
	{
		logger.finest(row.getName());
		if (curTable == null){
			logger.severe("table not open");
			return;
		}
		curTable.closeRow();
	}

	public void startCell(ICellContent cell)
	{
		logger.finest(cell.getName());
	}

	public void endCell(ICellContent cell)
	{
		logger.finest(cell.getName());
	}

	public void startText(ITextContent text)
	{
		logger.finest(this.getClass() + " " + text.getName() + " " + text.getText());
		curTable.addItem(text.getText());
	}

	public void startLabel(ILabelContent label)
	{
		logger.finest(label.getLabelText());
		startText(label);
	}

	public void startData(IDataContent data)
	{
		logger.finest(data.getName() + " " + data.getValue());
		startText(data);
	}

}