package callstack_oda_runtime;

import java.util.logging.Logger;

import callstack_oda_runtime.impl.Driver;

import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends Plugin
{

	// The plug-in ID
	public static final String PLUGIN_ID = "callstack_oda_runtime";
	private static Activator plugin;
	private static Logger logger = Logger.getLogger(Activator.class.getName());


	public Activator() {
		System.out.println(Activator.class.getName() + "\t=>\t<init>");
	}

	public void start(BundleContext context) throws Exception
	{
		super.start(context);
		System.out.println(Activator.class.getName() + "\t=>\tstart");
		plugin = this;
	}

	public void stop(BundleContext context) throws Exception
	{
		logger.fine("");
		plugin = null;
		super.stop(context);
	}

	public static Activator getDefault()
	{
		System.out.println(Activator.class.getName() + "\t=>\tgetDefault");
		return plugin;
	}

}
