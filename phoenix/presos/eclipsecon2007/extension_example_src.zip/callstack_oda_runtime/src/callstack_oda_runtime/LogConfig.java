/*******************************************************************************
 * Copyright (c) 2004 Actuate Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Actuate Corporation  - initial API and implementation
 *******************************************************************************/
package callstack_oda_runtime;

import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.LogConfiguration;
import org.eclipse.datatools.connectivity.oda.OdaException;
import org.eclipse.datatools.connectivity.oda.util.logging.Level;

/**
 * 
 */
public class LogConfig
{
	protected static Logger logger = Logger.getLogger(LogConfig.class.getName());

	/**
	 * Use LogConfiguration information provided by LogConfiguration option to 
	 * setup logging
	 * 
	 * 
	 */
	public static void setLogConfiguration(LogConfiguration logConfiguration) throws OdaException
	{
		final String methodName = "setLogConfiguration";
		final String className = LogConfig.class.getName();
		final String pkgName = className.substring(0, className.lastIndexOf("."));
		// Get logger for this driver package
		Logger pkgLogger = Logger.getLogger(pkgName);

		// convert from ODA log level to java.util.logging levels
		pkgLogger.setLevel(setLogLevel(logConfiguration.getLogLevel()));

		// if logging is OFF, no need to setup package handler or formatter
		if (pkgLogger.getLevel() == java.util.logging.Level.OFF)
			return; 

		// TODO:  Add code for non console handlers...
		Handler handler = new ConsoleHandler();
		if (handler == null)
		{
			logger.logp(java.util.logging.Level.WARNING, className, methodName, "Cannot create log handler for package.");
			return;
		}
		pkgLogger.addHandler(handler);
		
		Handler fileHandler = createFileHandler(logConfiguration);
		if (fileHandler != null)
			pkgLogger.addHandler(fileHandler);


		// set handler log level to that of package logger
		if (pkgLogger.getLevel() != null)
			handler.setLevel(pkgLogger.getLevel());

		// setup log formatter, if configured

		String formatterClassName = logConfiguration.getFormatterClassName();
		if (formatterClassName == null || formatterClassName.length() == 0)
		{
			return; // done, no need to set log formatter
		}

		// if existing formatter is of the same type as
		// configured formatter class, we are done
		if (handler.getFormatter() != null && formatterClassName.equals(handler.getFormatter().getClass().getName()))
		{
			return;
		}

		// assign new formatter to handler
		try
		{
			Class formatterClass = Class.forName(formatterClassName);
			handler.setFormatter((Formatter) formatterClass.newInstance());
		} catch (Exception ex)
		{
			logger.logp(java.util.logging.Level.WARNING, className, methodName, "Cannot setup Formatter object.", ex);
		}
	}

	private static Handler createFileHandler(LogConfiguration logConfiguration){
		
		return null;
	}
	
	private static java.util.logging.Level setLogLevel(int logLevel) throws OdaException
	{
		if (logLevel > Level.SEVERE)
			return java.util.logging.Level.OFF;
		
		switch (logLevel)
		{
		case Level.ALL:
			return java.util.logging.Level.ALL;
		case Level.FINEST:
			return java.util.logging.Level.FINEST;
		case Level.FINER:
			return java.util.logging.Level.FINER;
		case Level.FINE:
			return java.util.logging.Level.FINE;
		case Level.CONFIG:
			return java.util.logging.Level.CONFIG;
		case Level.INFO:
			return java.util.logging.Level.INFO;
		case Level.WARNING:
			return java.util.logging.Level.WARNING;
		case Level.SEVERE:
			return java.util.logging.Level.SEVERE;
		case Level.OFF:
			return java.util.logging.Level.OFF;
		}
		
		logger.log(java.util.logging.Level.INFO, "Invalid Log Level, using INFO");
		return java.util.logging.Level.INFO;
	}

}
