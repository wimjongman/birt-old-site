package callstack_oda_runtime;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

public class OdaLogFormatter extends Formatter
{

	public String format(LogRecord record) {

		StringBuffer sb = new StringBuffer();			

		// Get the level name and add it to the buffer
		sb.append(record.getSourceClassName());
		sb.append("\t=>\t");
		sb.append(record.getSourceMethodName());
		
		// Get the formatted message (includes localization 
		// and substitution of paramters) and add it to the buffer
		if (!"".equals(record.getMessage())){
			sb.append(" : ");
			sb.append(record.getMessage());
		}
		
		sb.append("\n");


		return sb.toString();
	}

}
