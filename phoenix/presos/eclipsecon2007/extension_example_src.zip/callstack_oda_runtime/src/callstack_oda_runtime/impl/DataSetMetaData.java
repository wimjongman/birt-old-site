/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IConnection;
import org.eclipse.datatools.connectivity.oda.IDataSetMetaData;
import org.eclipse.datatools.connectivity.oda.IResultSet;
import org.eclipse.datatools.connectivity.oda.OdaException;

/**
 * Implementation class of IDataSetMetaData for an ODA runtime driver.
 * <br>
 * For demo purpose, the auto-generated method stubs have
 * hard-coded implementation that assume this custom ODA data set
 * is capable of handling a query that returns a single result set and 
 * accepts scalar input parameters by index.
 * A custom ODA driver is expected to implement own data set specific
 * behavior in its place. 
 */
public class DataSetMetaData implements IDataSetMetaData
{
	private IConnection m_connection;
	private static Logger logger = Logger.getLogger(DataSetMetaData.class.getName());

	public DataSetMetaData(IConnection connection) {
		logger.fine("");
		m_connection = connection;
	}

	public IConnection getConnection() throws OdaException
	{
		logger.fine("");
		return m_connection;
	}

	public IResultSet getDataSourceObjects(String catalog, String schema, String object, String version) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public int getDataSourceMajorVersion() throws OdaException
	{
		logger.fine("");
		return 1;
	}

	public int getDataSourceMinorVersion() throws OdaException
	{
		logger.fine("");
		return 0;
	}

	public String getDataSourceProductName() throws OdaException
	{
		logger.fine("");
		return "Myodaruntime Data Source";
	}

	public String getDataSourceProductVersion() throws OdaException
	{
		logger.fine("");
		return Integer.toString(getDataSourceMajorVersion()) + "." + //$NON-NLS-1$
				Integer.toString(getDataSourceMinorVersion());
	}

	public int getSQLStateType() throws OdaException
	{
		logger.fine("");
		return IDataSetMetaData.sqlStateSQL99;
	}

	public boolean supportsMultipleResultSets() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public boolean supportsMultipleOpenResults() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public boolean supportsNamedResultSets() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public boolean supportsNamedParameters() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public boolean supportsInParameters() throws OdaException
	{
		logger.fine("");
		return true;
	}

	public boolean supportsOutParameters() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public int getSortMode()
	{
		logger.fine("");
		return IDataSetMetaData.sortModeNone;
	}

}
