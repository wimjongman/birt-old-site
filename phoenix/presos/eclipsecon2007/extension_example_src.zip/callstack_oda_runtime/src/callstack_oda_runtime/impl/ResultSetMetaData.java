/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IResultSetMetaData;
import org.eclipse.datatools.connectivity.oda.OdaException;

/**
 * Implementation class of IResultSetMetaData for an ODA runtime driver.
 * <br>
 * For demo purpose, the auto-generated method stubs have
 * hard-coded implementation that returns a pre-defined set
 * of meta-data and query results.
 * A custom ODA driver is expected to implement own data source specific
 * behavior in its place. 
 */
public class ResultSetMetaData implements IResultSetMetaData
{
	private static Logger logger = Logger.getLogger(ResultSetMetaData.class.getName());
	
	public ResultSetMetaData() {
		logger.fine("");
	}

	public int getColumnCount() throws OdaException
	{
		logger.fine("");
		return 2;
	}

	public String getColumnName(int index) throws OdaException
	{
		logger.fine("");
		return "Column" + index;
	}

	public String getColumnLabel(int index) throws OdaException
	{
		logger.fine("");
		return getColumnName(index); // default
	}

	public int getColumnType(int index) throws OdaException
	{
		logger.fine("");
		if (index == 1)
			return java.sql.Types.INTEGER; // as defined in data set extension manifest
		return java.sql.Types.CHAR; // as defined in data set extension manifest
	}

	public String getColumnTypeName(int index) throws OdaException
	{
		logger.fine("");
		int nativeTypeCode = getColumnType(index);
		return Driver.getNativeDataTypeName(nativeTypeCode);
	}

	public int getColumnDisplayLength(int index) throws OdaException
	{
		logger.fine("");
		return 8;
	}

	public int getPrecision(int index) throws OdaException
	{
		logger.fine("");
		return -1;
	}

	public int getScale(int index) throws OdaException
	{
		logger.fine("");
		return -1;
	}

	public int isNullable(int index) throws OdaException
	{
		logger.fine("");
		return IResultSetMetaData.columnNullableUnknown;
	}

}
