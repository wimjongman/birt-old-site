/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IParameterMetaData;
import org.eclipse.datatools.connectivity.oda.OdaException;

/**
 * Implementation class of IParameterMetaData for an ODA runtime driver.
 * <br>
 * For demo purpose, the auto-generated method stubs have
 * hard-coded implementation that returns a pre-defined set
 * of meta-data and query results.
 * A custom ODA driver is expected to implement own data source specific
 * behavior in its place. 
 */
public class ParameterMetaData implements IParameterMetaData
{
	private static Logger logger = Logger.getLogger(ParameterMetaData.class.getName());

	public ParameterMetaData() {
		logger.fine("");
	}

	public int getParameterCount() throws OdaException
	{
		logger.fine("");
		return 1;
	}

	public int getParameterMode(int param) throws OdaException
	{
		logger.fine("");
		return IParameterMetaData.parameterModeIn;
	}

	public int getParameterType(int param) throws OdaException
	{
		logger.fine("");
		return java.sql.Types.CHAR; // as defined in data set extension manifest
	}

	public String getParameterTypeName(int param) throws OdaException
	{
		logger.fine("");
		int nativeTypeCode = getParameterType(param);
		return Driver.getNativeDataTypeName(nativeTypeCode);
	}

	public int getPrecision(int param) throws OdaException
	{
		logger.fine("");
		return -1;
	}

	public int getScale(int param) throws OdaException
	{
		logger.fine("");
		return -1;
	}

	public int isNullable(int param) throws OdaException
	{
		logger.fine("");
		return IParameterMetaData.parameterNullableUnknown;
	}

}
