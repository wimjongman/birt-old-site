/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.util.logging.Logger;

import callstack_oda_runtime.LogConfig;

import org.eclipse.datatools.connectivity.oda.IConnection;
import org.eclipse.datatools.connectivity.oda.IDriver;
import org.eclipse.datatools.connectivity.oda.LogConfiguration;
import org.eclipse.datatools.connectivity.oda.OdaException;
import org.eclipse.datatools.connectivity.oda.util.manifest.DataTypeMapping;
import org.eclipse.datatools.connectivity.oda.util.manifest.ExtensionManifest;
import org.eclipse.datatools.connectivity.oda.util.manifest.ManifestExplorer;

/**
 * Implementation class of IDriver for an ODA runtime driver.
 */
public class Driver implements IDriver
{
	static String ODA_DATA_SOURCE_ID = "callstack_oda_runtime"; //$NON-NLS-1$
	protected static Logger logger = Logger.getLogger(Driver.class.getName());
	
	public Driver(){
		System.out.println(Driver.class.getName() + "\t=>\t<init>");
	}

	public IConnection getConnection(String dataSourceType) throws OdaException
	{
		logger.fine("");
		return new Connection();
	}

	public void setLogConfiguration(LogConfiguration logConfig) throws OdaException
	{
		LogConfig.setLogConfiguration(logConfig);
		logger.fine("Log Level " + logConfig.getLogLevel());
	}

	public int getMaxConnections() throws OdaException
	{
		logger.fine("");
		return 0; // no limit
	}

	public void setAppContext(Object context) throws OdaException
	{
		logger.fine("");
	}

	static ExtensionManifest getManifest() throws OdaException
	{
		logger.fine("");
		return ManifestExplorer.getInstance().getExtensionManifest(ODA_DATA_SOURCE_ID);
	}

	static String getNativeDataTypeName(int nativeDataTypeCode) throws OdaException
	{
		logger.fine("");
		DataTypeMapping typeMapping = getManifest().getDataSetType(null).getDataTypeMapping(nativeDataTypeCode);
		if (typeMapping != null)
			return typeMapping.getNativeType();
		return "Non-defined";
	}

}
