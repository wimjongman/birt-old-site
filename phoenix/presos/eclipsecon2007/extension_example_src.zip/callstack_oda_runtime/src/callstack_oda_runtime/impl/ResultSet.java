/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IBlob;
import org.eclipse.datatools.connectivity.oda.IClob;
import org.eclipse.datatools.connectivity.oda.IResultSet;
import org.eclipse.datatools.connectivity.oda.IResultSetMetaData;
import org.eclipse.datatools.connectivity.oda.OdaException;

/**
 * Implementation class of IResultSet for an ODA runtime driver.
 * <br>
 * For demo purpose, the auto-generated method stubs have
 * hard-coded implementation that returns a pre-defined set
 * of meta-data and query results.
 * A custom ODA driver is expected to implement own data source specific
 * behavior in its place. 
 */
public class ResultSet implements IResultSet
{
	private int m_maxRows;
	private int m_currentRowId;
	private static Logger logger = Logger.getLogger(ResultSet.class.getName());

	public ResultSet() {
		logger.fine("");
	}

	public IResultSetMetaData getMetaData() throws OdaException
	{
		logger.fine("");
		return new ResultSetMetaData();
	}

	public void setMaxRows(int max) throws OdaException
	{
		logger.fine("");
		m_maxRows = max;
	}

	protected int getMaxRows()
	{
		logger.fine("");
		return m_maxRows;
	}

	public boolean next() throws OdaException
	{
		logger.fine("");
		int maxRows = getMaxRows();
		if (maxRows <= 0) // no limit is specified
			maxRows = 5; // hard-coded for demo purpose

		if (m_currentRowId < maxRows)
		{
			m_currentRowId++;
			return true;
		}

		return false;
	}

	public void close() throws OdaException
	{
		logger.fine("");
		m_currentRowId = 0; // reset row counter
	}

	public int getRow() throws OdaException
	{
		logger.fine("");
		return m_currentRowId;
	}

	public String getString(int index) throws OdaException
	{
		logger.fine("");
		return "row" + getRow() + "_column" + index + " value";
	}

	public String getString(String columnName) throws OdaException
	{
		logger.fine("");
		return getString(findColumn(columnName));
	}

	public int getInt(int index) throws OdaException
	{
		logger.fine("");
		return getRow();
	}

	public int getInt(String columnName) throws OdaException
	{
		logger.fine("");
		return getInt(findColumn(columnName));
	}

	public double getDouble(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public double getDouble(String columnName) throws OdaException
	{
		logger.fine("");
		return getDouble(findColumn(columnName));
	}

	public BigDecimal getBigDecimal(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public BigDecimal getBigDecimal(String columnName) throws OdaException
	{
		logger.fine("");
		return getBigDecimal(findColumn(columnName));
	}

	public Date getDate(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public Date getDate(String columnName) throws OdaException
	{
		logger.fine("");
		return getDate(findColumn(columnName));
	}

	public Time getTime(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public Time getTime(String columnName) throws OdaException
	{
		logger.fine("");
		return getTime(findColumn(columnName));
	}

	public Timestamp getTimestamp(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public Timestamp getTimestamp(String columnName) throws OdaException
	{
		logger.fine("");
		return getTimestamp(findColumn(columnName));
	}

	public IBlob getBlob(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public IBlob getBlob(String columnName) throws OdaException
	{
		logger.fine("");
		return getBlob(findColumn(columnName));
	}

	public IClob getClob(int index) throws OdaException
	{
		logger.fine("");
		throw new UnsupportedOperationException();
	}

	public IClob getClob(String columnName) throws OdaException
	{
		logger.fine("");
		return getClob(findColumn(columnName));
	}

	public boolean wasNull() throws OdaException
	{
		logger.fine("");
		return false;
	}

	public int findColumn(String columnName) throws OdaException
	{
		logger.fine("");
		int columnId = 1; // dummy column id
		if (columnName == null || columnName.length() == 0)
			return columnId;
		String lastChar = columnName.substring(columnName.length() - 1, 1);
		try
		{
			columnId = Integer.parseInt(lastChar);
		} catch (NumberFormatException e)
		{
			// ignore, use dummy column id
		}
		return columnId;
	}

}
