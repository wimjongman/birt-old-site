/*
 *************************************************************************
 * Copyright (c) 2006 <<Your Company Name here>>
 *  
 *************************************************************************
 */

package callstack_oda_runtime.impl;

import java.util.Properties;
import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IConnection;
import org.eclipse.datatools.connectivity.oda.IDataSetMetaData;
import org.eclipse.datatools.connectivity.oda.IQuery;
import org.eclipse.datatools.connectivity.oda.OdaException;

/**
 * Implementation class of IConnection for an ODA runtime driver.
 */
public class Connection implements IConnection
{
	private boolean m_isOpen = false;
	private static Logger logger = Logger.getLogger(Connection.class.getName());

	public Connection() {
		super();
		logger.fine("");
	}
	
	public void open(Properties connProperties) throws OdaException
	{
		logger.fine("");
		m_isOpen = true;
	}

	public void setAppContext(Object context) throws OdaException
	{
		logger.fine("");
	}

	public void close() throws OdaException
	{
		logger.fine("");
		m_isOpen = false;
	}

	public boolean isOpen() throws OdaException
	{
		logger.fine("");
		return m_isOpen;
	}

	public IDataSetMetaData getMetaData(String dataSetType) throws OdaException
	{
		logger.fine("");
		return new DataSetMetaData(this);
	}

	public IQuery newQuery(String dataSetType) throws OdaException
	{
		logger.fine("");
		return new Query();
	}

	public int getMaxQueries() throws OdaException
	{
		logger.fine("");
		return 0; // no limit
	}

	public void commit() throws OdaException
	{
		logger.fine("");
	}

	public void rollback() throws OdaException
	{
		logger.fine("");
	}

}
