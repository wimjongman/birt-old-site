/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_annotate;

import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;

public class GoogleAnnotatePlugin extends Plugin
{
	private static GoogleAnnotatePlugin plugin;
	//Resource bundle.
	private ResourceBundle resourceBundle;
	private static Logger logger = Logger.getLogger(GoogleAnnotatePlugin.class.getName());

	/**
	 * The constructor.
	 */
	public GoogleAnnotatePlugin() {
		super();
		plugin = this;

		logger.finest("");
		try
		{
			resourceBundle = ResourceBundle.getBundle("google_annotate.GoogleAnnotatePluginResources");
		} catch (MissingResourceException x)
		{
			logger.finest("No resource bundler in constructor");
			resourceBundle = null;
		}
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception
	{
		logger.finest("");
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception
	{
		logger.finest("");
		super.stop(context);
	}

	/**
	 * Returns the shared instance.
	 */
	public static GoogleAnnotatePlugin getDefault()
	{
		logger.finest("");
		return plugin;
	}

	/**
	 * Returns the string from the plugin's resource bundle,
	 * or 'key' if not found.
	 */
	public static String getResourceString(String key)
	{
		logger.finest("");
		ResourceBundle bundle = GoogleAnnotatePlugin.getDefault().getResourceBundle();
		try
		{
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e)
		{
			logger.finest("Failure to find bundle ");
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle,
	 */
	public ResourceBundle getResourceBundle()
	{
		logger.finest("");
		return resourceBundle;
	}

}
