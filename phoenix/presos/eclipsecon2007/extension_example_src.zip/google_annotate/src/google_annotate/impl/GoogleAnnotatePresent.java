/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_annotate.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Logger;

import org.eclipse.birt.core.exception.BirtException;
import org.eclipse.birt.report.designer.ui.ReportPlatformUIImages;
import org.eclipse.birt.report.engine.extension.IRowSet;
import org.eclipse.birt.report.engine.extension.ReportItemPresentationBase;
import org.eclipse.birt.report.model.api.DataSetHandle;
import org.eclipse.birt.report.model.api.DesignElementHandle;
import org.eclipse.birt.report.model.api.ExtendedItemHandle;
import org.eclipse.birt.report.model.api.ReportItemHandle;
import org.eclipse.birt.report.model.elements.interfaces.IOdaDataSetModel;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;

/**
 *  This class provides the rendering capabilities for the sample report item
 *   When the Sample Report Item is used in a report design , and teh report is
 *   viewed, the methods in this class are invoked to perform the actal
 *   rendering  of the user defined report item.  
 */
public class GoogleAnnotatePresent extends ReportItemPresentationBase
{
	private File stopLightImageFile = null;
	private FileInputStream inputStream = null;
	private FileOutputStream outputStream = null;
	private String sExtension = null;
	private static Logger logger = Logger.getLogger(GoogleAnnotatePresent.class.getName());

	public void setModelObject(ExtendedItemHandle modelHandle)
	{
		super.setModelObject(modelHandle);
		logger.finest("");
	}

	public void setOutputFormat(String outputFormat)
	{
		logger.finest("");
		if (outputFormat.equalsIgnoreCase("HTML"))
		{
			sExtension = "PNG";
		} else if (outputFormat.equalsIgnoreCase("PDF"))
		{
			sExtension = "JPEG";
		} else
		{
			sExtension = outputFormat;
		}
	}

	public int getOutputType()
	{
		logger.finest("");
		return OUTPUT_AS_IMAGE_WITH_MAP;
	}

	public Object onRowSets(IRowSet[] rowSets) throws BirtException
	{
		logger.finest("");

		org.eclipse.swt.graphics.Image stopLightImage = ReportPlatformUIImages.getImage("outlineIcon.GoogleAnnotate");
		ImageLoader imageLoader = new ImageLoader();
		imageLoader.data = new ImageData[] { stopLightImage.getImageData() };

		try
		{
			stopLightImageFile = File.createTempFile("test", "." + sExtension);
			outputStream = new FileOutputStream(stopLightImageFile.getPath());
			inputStream = new FileInputStream(stopLightImageFile.getPath());
		} catch (IOException e)
		{
			e.printStackTrace();
		}

		imageLoader.save(outputStream, SWT.IMAGE_JPEG);

		return new Object[] { inputStream, getImageMap() };

	}

	/** 
	 * The image map is the 
	 * @return
	 */
	private String getImageMap()
	{
		StringBuilder dynamicReportCode = new StringBuilder();
		AuditBuilder auditBuilder = new AuditBuilder();
		
		//Query text is stored as a persistentGlobalVariable in the generate code
		// The key is based on the id of the item
		String id = new Long(modelHandle.getID()).toString();
		String query = (String)super.context.getPersistentGlobalVariable(id);
		
		dynamicReportCode.append(auditBuilder.buildAuditString());
		dynamicReportCode.append(getAreaTag(query));
		return dynamicReportCode.toString();
	}

	private class AuditBuilder
	{
		private StringBuffer sb;

		protected StringBuffer buildAuditString()
		{
			sb = new StringBuffer();
			addLine("<script type='text/javascript'>");
			addLine("  function auditReport(auditFormId){");
			addLine("	    ");
			addLine("	    var formDiv;");
			addLine("	    formDiv = document.createElement('div');");
			addLine("	    formDiv.style.position = 'absolute';");
			addLine("	    formDiv.style.bottom = 0;");
			addLine("	    formDiv.style.backgroundColor = '#cccccc';");
			addLine("	    formDiv.style.border = '1px solid #c0c0c0';");
			addLine("	    formDiv.style.padding = '1px 1px 1px 1px';");
			addLine("	    formDiv.id = 'auditDiv';");
			addLine("	    formDiv.innerHTML = [");
			addLine("	 	   \"<form id='\" + auditFormId + \"' onsubmit='javascript:xmlSubmit(this); return false;'>\",");
			addLine("	 	   \"<table summary=''>\",");
			addLine("	 	   \"  <tr><td colspan='6'>\" + auditFormId + \"</td></tr>\",");
			addLine("	 	   \"  <tr>\",");
			addLine("	 	   \"    <td>name:</td><td><input type='text' name='username' /></td>\",");
			addLine("	 	   \"    <td>approve:</td>\",");
			addLine("	 	   \"    <td>\",");
			addLine("	 	   \"      <input type='radio' name='auditValue' value='accept' checked >Accept\",");
			addLine("	 	   \"      <input type='radio' name='auditValue' value='reject' >Reject\",");
			addLine("	 	   \"    </td>\",");
			addLine("	 	   \"    <td>description:</td><td><textarea name='comment' ></textarea></td>\",");
			addLine("	 	   \"    <td colspan='2'><input type='submit' name='submit' value='submit'></button></td>   \",");
			addLine("	 	   \"  <tr>\",");
			addLine("	 	   \"</table>\",");
			addLine("	 	   \"</form>\"");
			addLine("	 	   ].join('');");
			addLine("	 	document.body.appendChild(formDiv);");
			addLine("	 	var form = document.getElementById(auditFormId);");
			addLine("	 	form[0].focus();");
			addLine("	 }");
			addLine("");
			addLine("  function xmlSubmit(frm) {");
			addLine("  	 var str = 'username: ' + frm.username.value;");
			addLine("  	 if (isAccepted(frm.auditValue)){ ");
			addLine("       str += ' accepts the report.  ';");
			addLine("    } else {");
			addLine("       str += ' rejects the report.  ';");
			addLine("    }");
			addLine("    str += 'Comment: ' + frm.comment.value;");
			addLine("  	 str += '.  Send a request to server side process to update Google with feed name: ';");
			addLine("    str += frm.id ");
			addLine("  	 str += '   NOTE: Google does not allow update of spread-sheets from the client, need server side process.'; ");
			addLine("  	 alert( str );");
			addLine("  }");
			addLine("");
			addLine("  function isAccepted(radioCtrl){  ");
			addLine("  	if (radioCtrl[0].checked == true)");
			addLine("  		 return true;");
			addLine("  	if (radioCtrl[1].checked == true)");
			addLine("  	    return false;");
			addLine("  }");
			addLine("");
			addLine("</script>");

			return sb;

		}

		private void addLine(String str)
		{
			sb.append(str);
			sb.append("\n");
		}

	}

	
	private StringBuffer getAreaTag(String qryTxt)
	{
		StringBuffer sb = new StringBuffer();
		sb.append("<area \n");
		sb.append("    shape =\"rect\"\n");
		sb.append("    coords=\"(0,0,53,18)\"\n");
		sb.append("    href =\"javascript:void(0);\"\n");
		sb.append("    onclick=\"javascript:auditReport('" + qryTxt + "');\"\n");
		sb.append("  >\n");
		sb.append("</area>\n");
		return sb;
	}

	public void finish()
	{
		logger.finest("");
		super.finish();

		try
		{
			outputStream.close();
			inputStream.close();
			stopLightImageFile.delete();

		} catch (IOException e)
		{
			logger.severe("Failure to close stream objects");
		}

	}

}
