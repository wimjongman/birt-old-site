/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_annotate.impl;

import java.util.logging.Logger;

import org.eclipse.birt.report.model.api.DesignElementHandle;
import org.eclipse.birt.report.model.api.extension.IMessages;
import org.eclipse.birt.report.model.api.extension.IReportItem;
import org.eclipse.birt.report.model.api.extension.IReportItemFactory;
/**
 *  This class provides methods which are called to create a new report
 *  Item , when the user drags and drops the Item from the Palette View
 *  to the report design.
 */
public class GoogleAnnotateFactory implements IReportItemFactory
{
	private static Logger logger = Logger.getLogger(GoogleAnnotateFactory.class.getName());

	public GoogleAnnotateFactory(){
		logger.finest("");
	}
	
	public IReportItem newReportItem(DesignElementHandle extendedItemHandle)
	{
		logger.finest("");
		return new GoogleAnnotateReportItem();
	}

	public IMessages getMessages()
	{
		logger.finest("");
		return null;
	}

}
