package google_annotate.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.logging.Logger;

import org.eclipse.birt.report.model.api.extension.ExtendedElementException;
import org.eclipse.birt.report.model.api.extension.IPropertyDefinition;
import org.eclipse.birt.report.model.api.extension.IReportItem;

public class GoogleAnnotateReportItem implements IReportItem
{
	private static Logger logger = Logger.getLogger(GoogleAnnotateReportItem.class.getName());

	public void checkProperty(String propName, Object value) throws ExtendedElementException
	{
		logger.finest("");
	}

	public IReportItem copy()
	{
		logger.finest("");
		return null;
	}

	public void deserialize(String propName, ByteArrayInputStream data) throws ExtendedElementException
	{
		logger.finest("");
	}

	public IPropertyDefinition[] getMethods()
	{
		logger.finest("");
		return null;
	}

	public Object getProperty(String propName)
	{
		logger.finest("");
		return null;
	}

	public IPropertyDefinition[] getPropertyDefinitions()
	{
		logger.finest("");
		return null;
	}

	public IPropertyDefinition getScriptPropertyDefinition()
	{
		logger.finest("");
		return null;
	}

	public boolean refreshPropertyDefinition()
	{
		logger.finest("");
		return false;
	}

	public ByteArrayOutputStream serialize(String propName)
	{
		logger.finest("");
		return null;
	}

	public void setProperty(String propName, Object value)
	{
		// TODO Auto-generated method stub

	}

	public List validate()
	{
		logger.finest("");
		return null;
	}


}
