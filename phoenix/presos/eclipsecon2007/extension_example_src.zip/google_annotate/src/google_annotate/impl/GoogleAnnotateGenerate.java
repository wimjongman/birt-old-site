package google_annotate.impl;

import java.io.OutputStream;
import java.util.logging.Logger;

import org.eclipse.birt.report.engine.api.script.IReportContext;
import org.eclipse.birt.report.engine.extension.IRowSet;
import org.eclipse.birt.report.engine.extension.ReportItemGenerationBase;
import org.eclipse.birt.report.engine.extension.Size;
import org.eclipse.birt.report.engine.script.internal.ReportContextImpl;
import org.eclipse.birt.report.model.api.DataSetHandle;
import org.eclipse.birt.report.model.api.DesignElementHandle;
import org.eclipse.birt.report.model.api.ExtendedItemHandle;
import org.eclipse.birt.report.model.api.ReportItemHandle;
import org.eclipse.birt.report.model.api.activity.SemanticException;
import org.eclipse.birt.report.model.api.extension.ExtendedElementException;
import org.eclipse.birt.report.model.api.extension.IReportItem;
import org.eclipse.birt.report.model.elements.interfaces.IOdaDataSetModel;

public class GoogleAnnotateGenerate extends ReportItemGenerationBase
{
	private static Logger logger = Logger.getLogger(GoogleAnnotateGenerate.class.getName());
	
	public void setModelObject(ExtendedItemHandle extendedItemHandle)
	{
		super.setModelObject(extendedItemHandle);
		IReportItem item = null;
		try
		{
			item = extendedItemHandle.getReportItem();
		} catch (ExtendedElementException e)
		{
			logger.severe(e.getMessage());
		}
		if (item == null)
		{
			try
			{
				extendedItemHandle.loadExtendedElement();
				item = extendedItemHandle.getReportItem();
			} catch (ExtendedElementException e)
			{
				logger.severe(e.getMessage());
			}
			if (item == null)
			{
				logger.severe("Unable to create ReportItem");
				return;
			}
		}
		logger.finest("");
	}

	/**
	 * The Query text has different levels of availability
	 * RunAndRenderTask:  Available at Generate and Presentation
	 * RunThenRenderTask: Available for Generate only, null value at Presentation
	 * 
	 * To avoid this issue, move the queryText to a persistent global value.
	 *
	 */
	private String getQueryText(){
		
		if (this.modelHandle == null)
			return null;
		
		String queryText = null;
		// To get queryText
		// DesignElementHandles do not have a method to the DataSet, but
		// ReportItemHandles do.  This loop will iterate up from the control
		// to the cell, row, table... until it finds a way to attach to the dataset
		DesignElementHandle objectElementHdl = modelHandle.getContainer();
		do
		{
			if (objectElementHdl instanceof ReportItemHandle)
			{
				ReportItemHandle objectItemHandle = (ReportItemHandle) objectElementHdl;
				DataSetHandle dataSetHandle = objectItemHandle.getDataSet();
				if (dataSetHandle != null)
				{
					queryText = (String) dataSetHandle.getProperty(IOdaDataSetModel.QUERY_TEXT_PROP);
					break;
				}
			}
			objectElementHdl = objectElementHdl.getContainer();
		} while (objectElementHdl != null);
		
		return queryText;
		
	}
	
	public void setApplicationClassLoader(ClassLoader loader)
	{
		logger.finest("");
	}

	public void setScriptContext(IReportContext context)
	{
		logger.finest("");
		String query = getQueryText();
		if (query == null)
			return;
		
		String id = new Long(modelHandle.getID()).toString(); 
		
		context.setPersistentGlobalVariable(id, query);
	}

	public void onRowSets(IRowSet[] rowSets)
	{
		logger.finest("");
	}

	public boolean needSerialization()
	{
		logger.finest("");
		return true;
	}

	public void finish()
	{
		logger.finest("");
	}

	public Size getSize()
	{
		logger.finest("");
		return null;
	}

	
	public void serialize(OutputStream ostream)
	{
		return;
	}
}
