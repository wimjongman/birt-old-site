/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_annotate.impl;

import java.util.logging.Logger;

import org.eclipse.birt.report.designer.ui.ReportPlatformUIImages;
import org.eclipse.birt.report.designer.ui.extensions.IReportItemImageProvider;
import org.eclipse.birt.report.model.api.ExtendedItemHandle;
import org.eclipse.swt.graphics.Image;

public class GoogleAnnotateUI implements IReportItemImageProvider {
	
	private static Logger logger = Logger.getLogger(GoogleAnnotateUI.class.getName());

   public Image getImage( ExtendedItemHandle handle ){
   	
   	logger.finest("");
   	Image rptImage = ReportPlatformUIImages.getImage("outlineIcon.GoogleAnnotate");
   	return rptImage;
   }
   
   public void disposeImage( ExtendedItemHandle handle, Image image ){
   	
   }


}
