/*******************************************************************************
 * Copyright (c) 2004 Actuate Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * Contributors:
 *  Actuate Corporation  - initial API and implementation
 *******************************************************************************/

package emitter_cvs;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.birt.report.engine.api.IRenderOption;
import org.eclipse.birt.report.engine.api.RenderOption;
import org.eclipse.birt.report.engine.content.IAutoTextContent;
import org.eclipse.birt.report.engine.content.IBandContent;
import org.eclipse.birt.report.engine.content.ICellContent;
import org.eclipse.birt.report.engine.content.IContainerContent;
import org.eclipse.birt.report.engine.content.IContent;
import org.eclipse.birt.report.engine.content.IDataContent;
import org.eclipse.birt.report.engine.content.IElement;
import org.eclipse.birt.report.engine.content.IForeignContent;
import org.eclipse.birt.report.engine.content.IGroupContent;
import org.eclipse.birt.report.engine.content.IImageContent;
import org.eclipse.birt.report.engine.content.ILabelContent;
import org.eclipse.birt.report.engine.content.IListBandContent;
import org.eclipse.birt.report.engine.content.IListContent;
import org.eclipse.birt.report.engine.content.IListGroupContent;
import org.eclipse.birt.report.engine.content.IPageContent;
import org.eclipse.birt.report.engine.content.IReportContent;
import org.eclipse.birt.report.engine.content.IRowContent;
import org.eclipse.birt.report.engine.content.IStyle;
import org.eclipse.birt.report.engine.content.ITableBandContent;
import org.eclipse.birt.report.engine.content.ITableContent;
import org.eclipse.birt.report.engine.content.ITableGroupContent;
import org.eclipse.birt.report.engine.content.ITextContent;
import org.eclipse.birt.report.engine.css.engine.value.birt.BIRTConstants;
import org.eclipse.birt.report.engine.emitter.ContentEmitterAdapter;
import org.eclipse.birt.report.engine.emitter.IContentEmitter;
import org.eclipse.birt.report.engine.emitter.IEmitterServices;
import org.eclipse.birt.report.engine.ir.EngineIRConstants;
import org.eclipse.birt.report.engine.presentation.ContentEmitterVisitor;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * <code>CvsReportEmitter</code> is a subclass of
 * <code>ContentEmitterAdapter</code> that implements IContentEmitter
 * interface to output IARD Report ojbects to Cvs file.
 * 
 * @version $Revision: 1.71 $ $Date: 2006/01/13 09:56:13 $
 */
public class CvsReportEmitter extends ContentEmitterAdapter
{

	public static final String OUTPUT_FORMAT_CVS = "CVS"; //$NON-NLS-1$
	public static final String REPORT_FILE = "report.cvs"; //$NON-NLS-1$
	protected OutputStream out = null;
	protected IReportContent report;
	protected IRenderOption renderOption;
	protected boolean outputMasterPageContent = true;
	protected CvsWriter writer;
	protected Stack<Boolean> stack = new Stack<Boolean>();
	protected IEmitterServices services;
	protected ContentEmitterVisitor contentVisitor;
	protected int columnNumbers;
	protected int currentColumn;
	protected boolean exportTableElement = true;
	protected Logger logger = Logger.getLogger(CvsReportEmitter.class.getName());
	
	/**
	 * the constructor
	 */
	public CvsReportEmitter() {
		super();
		contentVisitor = new ContentEmitterVisitor(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#initialize(org.eclipse.birt.report.engine.emitter.IEmitterServices)
	 */
	public void initialize(IEmitterServices services)
	{
		this.services = services;

		Object fd = services.getOption(RenderOption.OUTPUT_FILE_NAME);
		File file = null;
		try
		{
			if (fd != null)
			{
				file = new File(fd.toString());
				File parent = file.getParentFile();
				if (parent != null && !parent.exists())
				{
					parent.mkdirs();
				}
				out = new BufferedOutputStream(new FileOutputStream(file));
			}
		} catch (FileNotFoundException e)
		{
			logger.log(Level.WARNING, e.getMessage(), e);
		}

		if (out == null)
		{
			Object value = services.getOption(RenderOption.OUTPUT_STREAM);
			if (value != null && value instanceof OutputStream)
			{
				out = (OutputStream) value;
			} else
			{
				try
				{

					file = new File(REPORT_FILE);
					out = new BufferedOutputStream(new FileOutputStream(file));
				} catch (FileNotFoundException e)
				{

					logger.log(Level.SEVERE, e.getMessage(), e);
				}
			}
		}

		writer = new CvsWriter();

	}

	/**
	 * @return the <code>Report</code> object.
	 */
	public IReportContent getReport()
	{
		return report;
	}

	/**
	 * Pushes the Boolean indicating whether or not the item is hidden according
	 * to the style
	 * 
	 * @param style
	 */
	public void push(IStyle style)
	{
		stack.push(new Boolean(peek(style)));
	}

	/**
	 * Pops the element of the stack
	 * 
	 * @return the boolean indicating whether or not the item is hidden
	 */
	public boolean pop()
	{
		return ((Boolean) stack.pop()).booleanValue();
	}

	/**
	 * Peeks the element of stack
	 * 
	 * @param style
	 * @return the boolean indicating whether or not the item is hidden
	 */
	public boolean peek(IStyle style)
	{
		boolean isHidden = false;
		if (!stack.empty())
		{
			isHidden = ((Boolean) stack.peek()).booleanValue();
		}
		if (!isHidden)
		{
			String formats = style.getVisibleFormat();
			if (formats != null
					&& (formats.indexOf(EngineIRConstants.FORMAT_TYPE_VIEWER) >= 0 || formats.indexOf(BIRTConstants.BIRT_ALL_VALUE) >= 0))
			{
				isHidden = true;
			}
		}
		return isHidden;
	}

	/**
	 * Checks if the current item is hidden
	 * 
	 * @return a boolean value
	 */
	public boolean isHidden()
	{
		return ((Boolean) stack.peek()).booleanValue();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#getOutputFormat()
	 */
	public String getOutputFormat()
	{
		return OUTPUT_FORMAT_CVS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#start(org.eclipse.birt.report.engine.content.IReportContent)
	 */
	public void start(IReportContent report)
	{

		logger.log(Level.FINE, "[CvsReportEmitter] Start emitter."); //$NON-NLS-1$

		this.report = report;
		writer.open(out, "UTF-8"); //$NON-NLS-1$

		writer.startWriter();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#end(org.eclipse.birt.report.engine.content.IReportContent)
	 */
	public void end(IReportContent report)
	{
		logger.log(Level.FINE, "[CvsReportEmitter] End report."); //$NON-NLS-1$
		writer.endWriter();
		writer.close();
		if (out != null)
		{
			try
			{
				out.close();
			} catch (IOException e)
			{
				logger.log(Level.WARNING, e.getMessage(), e);
			}
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startPage(org.eclipse.birt.report.engine.content.IPageContent)
	 */
	public void startPage(IPageContent page)
	{

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#endPage(org.eclipse.birt.report.engine.content.IPageContent)
	 */
	public void endPage(IPageContent page)
	{

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startTable(org.eclipse.birt.report.engine.content.ITableContent)
	 */
	public void startTable(ITableContent table)
	{
		assert table != null;
		columnNumbers = table.getColumnCount();

		IStyle mergedStyle = table.getStyle();
		push(mergedStyle);
		if (isHidden())
		{
			return;
		}
		logger.log(Level.FINE, "[CvsTableEmitter] Start table"); //$NON-NLS-1$

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#endTable(org.eclipse.birt.report.engine.content.ITableContent)
	 */
	public void endTable(ITableContent table)
	{
		if (pop())
		{
			return;
		}

		logger.log(Level.FINE, "[CvsTableEmitter] End table"); //$NON-NLS-1$

	}

	public void startRow(IRowContent row)
	{
		assert row != null;

		if (isRowInFooterBand(row))
			exportTableElement = false;

		IStyle mergedStyle = row.getStyle();
		push(mergedStyle);
		if (isHidden())
		{
			return;
		}
		currentColumn = 0;
	}

	boolean isRowInFooterBand(IRowContent row)
	{
		IElement parent = row.getParent();
		if (!(parent instanceof IBandContent))
		{
			return false;
		}
		IBandContent band = (IBandContent) parent;
		if (band.getBandType() == IBandContent.BAND_FOOTER)
		{
			return true;
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#endRow(org.eclipse.birt.report.engine.content.IRowContent)
	 */
	public void endRow(IRowContent row)
	{
		if (pop())
		{
			return;
		}

		if (exportTableElement)
			writer.closeTag(CvsTags.TAG_CR);

		exportTableElement = true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startCell(org.eclipse.birt.report.engine.content.ICellContent)
	 */
	public void startCell(ICellContent cell)
	{
		cell.getParent();
		if (isHidden())
		{
			return;
		}
		currentColumn = currentColumn + 1;
		logger.log(Level.FINE, "[CvsTableEmitter] Start cell."); //$NON-NLS-1$

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#endCell(org.eclipse.birt.report.engine.content.ICellContent)
	 */
	public void endCell(ICellContent cell)
	{
		if (isHidden())
		{
			return;
		}
		logger.log(Level.FINE, "[CvsReportEmitter] End cell."); //$NON-NLS-1$

		if ((currentColumn < columnNumbers) && exportTableElement)
		{
			writer.closeTag(CvsTags.TAG_COMMA);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startContainer(org.eclipse.birt.report.engine.content.IContainerContent)
	 */
	public void startContainer(IContainerContent container)
	{

		IStyle mergedStyle = container.getStyle();
		push(mergedStyle);
		if (isHidden())
		{
			return;
		}
		logger.log(Level.FINE, "[CvsReportEmitter] Start container"); //$NON-NLS-1$

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#endContainer(org.eclipse.birt.report.engine.content.IContainerContent)
	 */
	public void endContainer(IContainerContent container)
	{
		if (pop())
		{
			return;
		}
		logger.log(Level.FINE, "[CvsContainerEmitter] End container"); //$NON-NLS-1$
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startText(org.eclipse.birt.report.engine.content.ITextContent)
	 */
	public void startText(ITextContent text)
	{
		IStyle mergedStyle = text.getStyle();
		if (peek(mergedStyle))
		{
			return;
		}
		logger.log(Level.FINE, "[CvsReportEmitter] Start text"); //$NON-NLS-1$

		String textValue = text.getText();

		if (exportTableElement)
		{
			writer.text(textValue);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startForeign(org.eclipse.birt.report.engine.content.IForeignContent)
	 */
	public void startForeign(IForeignContent foreign)
	{

	}

	public void startNode(Node node, HashMap cssStyles)
	{
		String nodeName = node.getNodeName();
		HashMap cssStyle = (HashMap) cssStyles.get(node);
		writer.openTag(nodeName);
		NamedNodeMap attributes = node.getAttributes();
		if (attributes != null)
		{
			for (int i = 0; i < attributes.getLength(); i++)
			{
				Node attribute = attributes.item(i);
				String attrName = attribute.getNodeName();
				String attrValue = attribute.getNodeValue();

				if (attrValue != null)
				{
					if ("img".equalsIgnoreCase(nodeName) && "src".equalsIgnoreCase(attrName))
					{
						String attrValueTrue = handleStyleImage(attrValue);
						if (attrValueTrue != null)
						{
							attrValue = attrValueTrue;
						}
					}
					writer.attribute(attrName, attrValue);
				}
			}
		}
		if (cssStyle != null)
		{
			StringBuffer buffer = new StringBuffer();
			Iterator ite = cssStyle.entrySet().iterator();
			while (ite.hasNext())
			{
				Map.Entry entry = (Map.Entry) ite.next();
				Object keyObj = entry.getKey();
				Object valueObj = entry.getValue();
				if (keyObj == null || valueObj == null)
				{
					continue;
				}
				String key = keyObj.toString();
				String value = valueObj.toString();
				buffer.append(key);
				buffer.append(":");
				if ("background-image".equalsIgnoreCase(key))
				{
					String valueTrue = handleStyleImage(value);
					if (valueTrue != null)
					{
						value = valueTrue;
					}
					buffer.append("url(");
					buffer.append(value);
					buffer.append(")");
				} else
				{
					buffer.append(value.replaceAll(" ", ""));
				}
				buffer.append(";");
			}
			if (buffer.length() != 0)
			{
				writer.attribute("style", buffer.toString());
			}
		}
	}

	public void endNode(Node node)
	{
		writer.closeTag(node.getNodeName());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startLabel(org.eclipse.birt.report.engine.content.ILabelContent)
	 */
	public void startLabel(ILabelContent label)
	{
		startText(label);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startData(org.eclipse.birt.report.engine.content.IDataContent)
	 */
	public void startData(IDataContent data)
	{
		startText(data);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.birt.report.engine.emitter.IContentEmitter#startImage(org.eclipse.birt.report.engine.content.IImageContent)
	 */
	public void startImage(IImageContent image)
	{
		exportTableElement = false;
	}

	/**
	 * handle style image
	 * 
	 * @param uri
	 *            uri in style image
	 * @return
	 */
	public String handleStyleImage(String uri)
	{
		String id = null;
		return id;
	}

	public void endContent(IContent content)
	{
		// TODO Auto-generated method stub
		
	}

	public void endGroup(IGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

	public void endList(IListContent list)
	{
		// TODO Auto-generated method stub
		
	}

	public void endListBand(IListBandContent listBand)
	{
		// TODO Auto-generated method stub
		
	}

	public void endListGroup(IListGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

	public void endTableBand(ITableBandContent band)
	{
		// TODO Auto-generated method stub
		
	}

	public void endTableGroup(ITableGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

	public void startAutoText(IAutoTextContent autoText)
	{
		// TODO Auto-generated method stub
		
	}

	public void startContent(IContent content)
	{
		// TODO Auto-generated method stub
		
	}

	public void startGroup(IGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

	public void startList(IListContent list)
	{
		// TODO Auto-generated method stub
		
	}

	public void startListBand(IListBandContent listBand)
	{
		// TODO Auto-generated method stub
		
	}

	public void startListGroup(IListGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

	public void startTableBand(ITableBandContent band)
	{
		// TODO Auto-generated method stub
		
	}

	public void startTableGroup(ITableGroupContent group)
	{
		// TODO Auto-generated method stub
		
	}

}