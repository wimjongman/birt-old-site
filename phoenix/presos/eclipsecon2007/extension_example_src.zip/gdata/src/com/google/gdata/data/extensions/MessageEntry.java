/* Copyright (c) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.google.gdata.data.extensions;

import java.util.List;

import com.google.gdata.data.BaseEntry;
import com.google.gdata.data.Category;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.util.Namespaces;

/**
 * Extension class for manipulating entries of the Message kind.
 *
 * 
 * 
 */
public class MessageEntry extends BaseEntry<MessageEntry> {


  /** Category used to label any entry that contains Message extensions */
  public static final Category MESSAGE_CATEGORY =
    new Category(Namespaces.gKind, Namespaces.gPrefix + "message");

  /** Category used to label starred message feeds and entries. */
  public static final Category STARRED_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.starred");
  /** Category used to label unread message feeds and entries. */
  public static final Category UNREAD_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.unread");
  /** Category used to label chat message feeds and entries. */
  public static final Category CHAT_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.chat");
  /** Category used to label spam message feeds and entries. */
  public static final Category SPAM_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.spam");
  /** Category used to label sent message feeds and entries. */
  public static final Category SENT_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.sent");
  /** Category used to label inbox message feeds and entries. */
  public static final Category INBOX_CATEGORY =
    new Category(Namespaces.g, Namespaces.gPrefix + "message.inbox");

  /**
   * Constructs a new MessageEntry instance with the appropriate category
   * to indicate that it is a message.
   */
  public MessageEntry() {
    super();
    getCategories().add(MESSAGE_CATEGORY);
  }


  /**
   * Constructs a new EventEntry instance by doing a shallow copy of data
   * from an existing BaseEntry instance.
   */
  public MessageEntry(BaseEntry sourceEntry) {
    super(sourceEntry);
  }


  /**
   * Initializes an ExtensionProfile based upon the extensions expected
   * by an MessageEntry.
   */
  public void declareExtensions(ExtensionProfile extProfile) {
    extProfile.declareEntryExtension(Rating.getDefaultDescription(false));
    extProfile.declareEntryExtension(When.getDefaultDescription(false));
    extProfile.declareEntryExtension(GeoPt.getDefaultDescription(false));
    extProfile.declareEntryExtension(Who.getDefaultDescription());
  }


  public Rating getRating() {
    return getExtension(Rating.class);
  }


  public void setRating(Rating rating) {
    setExtension(rating);
  }

  public When getTime() {
    return getExtension(When.class);
  }

  public void setTime(When when) {
    setExtension(when);
  }

  public GeoPt getGeoPt() {
    return getExtension(GeoPt.class);
  }

  public void setGeoPt(GeoPt geoPt) {
    setExtension(geoPt);
  }

  public List<Who> getWhoList() {
    return getRepeatingExtension(Who.class);
  }
}
