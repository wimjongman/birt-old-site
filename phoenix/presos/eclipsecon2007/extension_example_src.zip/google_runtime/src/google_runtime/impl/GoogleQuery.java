/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_runtime.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.eclipse.datatools.connectivity.oda.IParameterMetaData;
import org.eclipse.datatools.connectivity.oda.IQuery;
import org.eclipse.datatools.connectivity.oda.IResultSet;
import org.eclipse.datatools.connectivity.oda.IResultSetMetaData;
import org.eclipse.datatools.connectivity.oda.OdaException;
import org.eclipse.datatools.connectivity.oda.SortSpec;

import com.google.gdata.client.spreadsheet.FeedURLFactory;
import com.google.gdata.client.spreadsheet.ListQuery;
import com.google.gdata.client.spreadsheet.SpreadsheetService;
import com.google.gdata.data.spreadsheet.ListFeed;
import com.google.gdata.util.ServiceException;

/**
 * Implementation class of IQuery for an ODA runtime driver. <br>
 * For demo purpose, the auto-generated method stubs have hard-coded
 * implementation that returns a pre-defined set of meta-data and query results.
 * A custom ODA driver is expected to implement own data source specific
 * behavior in its place.
 */
public class GoogleQuery implements IQuery
{
	private int m_maxRows;
	private URL targetURL;
	private SpreadsheetService service;
	private ListFeed feed;
	private String queryText;
	protected Logger logger = Logger.getLogger(GoogleQuery.class.getName());

	public GoogleQuery(SpreadsheetService newService) {
		service = newService;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#prepare(java.lang.String)
	 */
	public void prepare(String queryText) throws OdaException
	{
		// each type of dataSet will use the same query object
		// so if the queryText changes, need to change the current feed
		if (feed != null && this.queryText != null && this.queryText.equalsIgnoreCase(queryText))
			return;
		
		this.queryText = queryText;
		createFeed();
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setAppContext(java.lang.Object)
	 */
	public void setAppContext(Object context) throws OdaException
	{
		logger.finest("APP CONTEXT ");
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#close()
	 */
	public void close() throws OdaException
	{
		logger.finest("CLOSE");
		logger.finest("");
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#getMetaData()
	 */
	public IResultSetMetaData getMetaData() throws OdaException
	{
		logger.finest("ResultSetMetaData");
		testFeed("getMetaData");

		return new GoogleResultSetMetaData(feed.getEntries());
	}

	private void testFeed(String methodName) throws OdaException
	{
		if (feed == null || feed.getEntries() == null || feed.getEntries().size() == 0)
			throw new OdaException("Data Feed is null or empty in " + methodName);
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#executeQuery()
	 */
	public IResultSet executeQuery() throws OdaException
	{
		logger.finest("EXECUTE QUERY");
		testFeed("executeQuery");
		
		IResultSet resultSet = new GoogleResultSet(feed);
		resultSet.setMaxRows(getMaxRows());
		return resultSet;
	}
	
	private void createFeed() throws OdaException{
		System.out.println("create feed");

		try
		{
			// feed URL
			targetURL = new URL(queryText);
			// href Link
			//targetURL = computeListFeedLocation(queryText);
		} catch (MalformedURLException e)
		{
			System.out.println("Query: URL failure");
			throw new OdaException(e);
		}

		ListQuery query = new ListQuery(targetURL);
		try
		{
			feed = service.query(query, ListFeed.class);
		} catch (IOException e)
		{
			System.out.println("Query: IO Exception");
			throw new OdaException(e);
		} catch (ServiceException e)
		{
			System.out.println("Query: ServiceException");
			throw new OdaException(e);
		}

	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setProperty(java.lang.String,
	 *      java.lang.String)
	 */
	public void setProperty(String name, String value) throws OdaException
	{
		logger.finest("Property " + name + " : " + value);
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setMaxRows(int)
	 */
	public void setMaxRows(int max) throws OdaException
	{
		logger.finest("SetMaxRows " + max);
		m_maxRows = max;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#getMaxRows()
	 */
	public int getMaxRows() throws OdaException
	{
		logger.finest("GetMaxRows ");
		return m_maxRows;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#clearInParameters()
	 */
	public void clearInParameters() throws OdaException
	{
		logger.finest("ClearInParameters");
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setInt(java.lang.String,
	 *      int)
	 */
	public void setInt(String parameterName, int value) throws OdaException
	{
		logger.finest("SetIntName");
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setInt(int, int)
	 */
	public void setInt(int parameterId, int value) throws OdaException
	{
		logger.finest("SetIntId");
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setDouble(java.lang.String,
	 *      double)
	 */
	public void setDouble(String parameterName, double value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setDouble(int, double)
	 */
	public void setDouble(int parameterId, double value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setBigDecimal(java.lang.String,
	 *      java.math.BigDecimal)
	 */
	public void setBigDecimal(String parameterName, BigDecimal value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setBigDecimal(int,
	 *      java.math.BigDecimal)
	 */
	public void setBigDecimal(int parameterId, BigDecimal value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setString(java.lang.String,
	 *      java.lang.String)
	 */
	public void setString(String parameterName, String value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setString(int,
	 *      java.lang.String)
	 */
	public void setString(int parameterId, String value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setDate(java.lang.String,
	 *      java.sql.Date)
	 */
	public void setDate(String parameterName, Date value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setDate(int,
	 *      java.sql.Date)
	 */
	public void setDate(int parameterId, Date value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setTime(java.lang.String,
	 *      java.sql.Time)
	 */
	public void setTime(String parameterName, Time value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setTime(int,
	 *      java.sql.Time)
	 */
	public void setTime(int parameterId, Time value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setTimestamp(java.lang.String,
	 *      java.sql.Timestamp)
	 */
	public void setTimestamp(String parameterName, Timestamp value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to named input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setTimestamp(int,
	 *      java.sql.Timestamp)
	 */
	public void setTimestamp(int parameterId, Timestamp value) throws OdaException
	{
	// TODO Auto-generated method stub
	// only applies to input parameter
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#findInParameter(java.lang.String)
	 */
	public int findInParameter(String parameterName) throws OdaException
	{
		// TODO Auto-generated method stub
		// only applies to named input parameter
		return 0;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#getParameterMetaData()
	 */
	public IParameterMetaData getParameterMetaData() throws OdaException
	{
		logger.finest("GetParameterMetaData");
		return new GoogleParameterMetaData();
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#setSortSpec(org.eclipse.datatools.connectivity.oda.SortSpec)
	 */
	public void setSortSpec(SortSpec sortBy) throws OdaException
	{
		// TODO Auto-generated method stub
		// only applies to sorting, assumes not supported
		throw new UnsupportedOperationException();
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IQuery#getSortSpec()
	 */
	public SortSpec getSortSpec() throws OdaException
	{
		// TODO Auto-generated method stub
		// only applies to sorting
		return null;
	}

}
