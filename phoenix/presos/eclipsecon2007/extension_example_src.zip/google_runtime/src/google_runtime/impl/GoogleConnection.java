/*******************************************************************************
 * Copyright (c) 2007 Innovent Solutions, Inc.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Innovent Solutions, Inc.  - initial API and implementation
 *******************************************************************************/

package google_runtime.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.eclipse.datatools.connectivity.oda.IConnection;
import org.eclipse.datatools.connectivity.oda.IDataSetMetaData;
import org.eclipse.datatools.connectivity.oda.IQuery;
import org.eclipse.datatools.connectivity.oda.OdaException;

import com.google.gdata.client.spreadsheet.SpreadsheetService;
import com.google.gdata.util.AuthenticationException;

/**
 * Implementation class of IConnection for an ODA runtime driver.
 */
public class GoogleConnection implements IConnection {
	private boolean isOpen = false;
	private SpreadsheetService service;
	private Map<String, IQuery> queryMap = new HashMap<String, IQuery>();

	// private Logger logger = LoggerHelper;

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#open(java.util.Properties)
	 */
	public void open(Properties connProperties) throws OdaException {
		// Instantiate the Google service using a username.

		service = new SpreadsheetService("innovent - google ODA - 1");
		String user = connProperties.getProperty("username");
		String pass = connProperties.getProperty("password");
		try {
			service.setUserCredentials(user, pass);
		} catch (AuthenticationException e) {
			System.out.println("failed to connect");
			e.printStackTrace();
			throw new OdaException(e);
		}

		isOpen = true;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#setAppContext(java.lang.Object)
	 */
	public void setAppContext(Object context) throws OdaException {
		// do nothing; assumes no support for pass-through context
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#close()
	 */
	public void close() throws OdaException {
		service = null;
		isOpen = false;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#isOpen()
	 */
	public boolean isOpen() throws OdaException {
		return isOpen;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#getMetaData(java.lang.String)
	 */
	public IDataSetMetaData getMetaData(String dataSetType) throws OdaException {
		// assumes that this driver supports only one type of data set,
		// ignores the specified dataSetType
		return new GoogleDataSetMetaData(this);
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#newQuery(java.lang.String)
	 */
	public IQuery newQuery(String dataSetType) throws OdaException {
		// This method gets called at multiple points in build cycle
		// if you don't want to run your query multiple times for each report, 
		// you need to cache the query.
		IQuery aQuery = queryMap.get(dataSetType);
		if (aQuery != null)
			return aQuery;
		
		aQuery = new GoogleQuery(service);
		if (aQuery == null)
			throw new OdaException("Failure to create Google Query");
		
		queryMap.put(dataSetType, aQuery);
		
		return aQuery;
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#getMaxQueries()
	 */
	public int getMaxQueries() throws OdaException {
		return 0; // no limit
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#commit()
	 */
	public void commit() throws OdaException {
		// do nothing; assumes no transaction support needed
	}

	/*
	 * @see org.eclipse.datatools.connectivity.oda.IConnection#rollback()
	 */
	public void rollback() throws OdaException {
		// do nothing; assumes no transaction support needed
	}

}
