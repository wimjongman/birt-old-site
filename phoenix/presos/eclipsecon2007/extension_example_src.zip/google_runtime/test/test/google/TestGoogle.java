package test.google;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import junit.framework.TestCase;
import com.google.gdata.client.spreadsheet.FeedURLFactory;
import com.google.gdata.client.spreadsheet.ListQuery;
import com.google.gdata.client.spreadsheet.SpreadsheetService;
import com.google.gdata.data.spreadsheet.CellEntry;
import com.google.gdata.data.spreadsheet.ListEntry;
import com.google.gdata.data.spreadsheet.ListFeed;
import com.google.gdata.data.spreadsheet.SpreadsheetEntry;
import com.google.gdata.data.spreadsheet.SpreadsheetFeed;
import com.google.gdata.data.spreadsheet.WorksheetEntry;
import com.google.gdata.data.spreadsheet.WorksheetFeed;
import com.google.gdata.util.AuthenticationException;
import com.google.gdata.util.ServiceException;

public class TestGoogle extends TestCase
{

	private String urlString;
	private SpreadsheetService service;
	private final String AUDIT = "AUDIT";

	protected void setUp() throws MalformedURLException, AuthenticationException
	{
		service = new SpreadsheetService("innovent - birtDataSet - 1");
		service.setUserCredentials("info@innoventsolutions.com", "innovent2007");
		urlString = "http://spreadsheets.google.com/ccc?id=o05323973627365490072.7329113802600165656.13362180878445312663.7856374161918025760";
	}

	public void tstList() throws IOException, ServiceException
	{

		URL url = computeListFeedLocation(urlString);
		ListQuery query = new ListQuery(url);
		ListFeed feed = service.query(query, ListFeed.class);
		System.out.println("num entries: " + feed.getEntries().size());
		System.out.println("total results: " + feed.getTotalResults());
		for (ListEntry listEntry : feed.getEntries())
		{
			for (String tag : listEntry.getCustomElements().getTags())
			{
				// First col value: listEntry.getTitle().getPlainText()
				// 
				System.out.println("row(" + listEntry.getTitle().getPlainText() + ") col( " + tag + ") "
						+ listEntry.getCustomElements().getValue(tag));
			}
		}
	}

	public void testDisplayWorksheetFeeds() throws IOException, ServiceException
	{
		// get all SpreadSheets for the user
		FeedURLFactory factory = FeedURLFactory.getDefault();
		SpreadsheetFeed spreadsheet_feed = service.getFeed(factory.getSpreadsheetsFeedUrl(), SpreadsheetFeed.class);

		// Iterate over each SpreadSheet, get the worksheet feed.
		for (SpreadsheetEntry spreadsheet : spreadsheet_feed.getEntries())
		{
			System.out.println(spreadsheet.getTitle().getPlainText());
			WorksheetFeed worksheet_feed = service.getFeed(spreadsheet.getWorksheetFeedUrl(), WorksheetFeed.class);
			for (WorksheetEntry worksheet : worksheet_feed.getEntries())
			{
				System.out.println(" -" + worksheet.getTitle().getPlainText() + " " + worksheet.getListFeedUrl());
			}
		}
	}

	public void testAuditSpreadSheets() throws IOException, ServiceException
	{
		// get all SpreadSheets for the user
		FeedURLFactory factory = FeedURLFactory.getDefault();
		SpreadsheetFeed spreadsheet_feed = service.getFeed(factory.getSpreadsheetsFeedUrl(), SpreadsheetFeed.class);

		WorksheetEntry auditSheet = null;

		// Iterate over each SpreadSheet, get the worksheet feed.
		for (SpreadsheetEntry spreadsheet : spreadsheet_feed.getEntries())
		{
			WorksheetFeed worksheet_feed = service.getFeed(spreadsheet.getWorksheetFeedUrl(), WorksheetFeed.class);
			for (WorksheetEntry worksheet : worksheet_feed.getEntries())
			{
				if (AUDIT.equalsIgnoreCase(worksheet.getTitle().getPlainText()))
				{
					auditSheet = worksheet;
					break;
				}
			}

			// no audit sheet, need to add one
			if (auditSheet == null)
			{
				this.fail("No Audit Sheet");
				auditSheet = new WorksheetEntry();
				//TextConstruct tc = new TextConstruct();
				//auditSheet.setTitle(tc);
				//service.insert(, )
			}

			// Just add the cells, overwrite any existing values
			CellEntry entry = new CellEntry(1, 1, "name");
			service.insert(auditSheet.getCellFeedUrl(), entry);
			entry = new CellEntry(1, 2, "accept");
			service.insert(auditSheet.getCellFeedUrl(), entry);
			entry = new CellEntry(1, 3, "comment");
			service.insert(auditSheet.getCellFeedUrl(), entry);

			// This is the comment block...
			ListEntry myEntry = new ListEntry();
			myEntry.getCustomElements().setValueLocal("name", "Fred Flintsone");
			myEntry.getCustomElements().setValueLocal("accept", "yes");
			myEntry.getCustomElements().setValueLocal("comment", "This is the best thing since sliced bread");
			service.insert(auditSheet.getListFeedUrl(), myEntry);

		}

	}

	public void tstWritePage2() throws IOException, ServiceException
	{
		URL url = computeCellFeedLocation(urlString);
		CellEntry newEntry = new CellEntry(100, 1, "test");
		service.insert(url, newEntry);
	}

	/**
	 * Computes the URL of the list feed for the spreadsheet. It is via this URL
	 * that all requests are made.
	 * 
	 * @throws MalformedURLException
	 */
	private URL computeListFeedLocation(String spreadsheetUrl) throws MalformedURLException
	{

		URL url = new URL(spreadsheetUrl);
		System.out.println(url.getHost());
		FeedURLFactory factory = new FeedURLFactory("http://" + url.getHost());

		// Parses the entire URL to find the spreadsheet key.
		String spreadsheetKey = FeedURLFactory.getSpreadsheetKeyFromUrl(spreadsheetUrl);

		System.out.println("key: " + spreadsheetKey);
		// Gets the default (first) worksheet's list feed for this spreadsheet
		return factory.getListFeedUrl(spreadsheetKey, "default", "private", "full");
	}

	/**
	 * Computes the URL of the cells feed for the spreadsheet.
	 */
	public URL computeCellFeedLocation(String spreadsheetUrl) throws MalformedURLException
	{

		URL url = new URL(spreadsheetUrl);
		FeedURLFactory factory = new FeedURLFactory("http://" + url.getHost());

		// Parses the entire URL to find the spreadsheet key.
		String spreadsheetKey = FeedURLFactory.getSpreadsheetKeyFromUrl(spreadsheetUrl);

		// Gets the default (first) worksheet's list feed for this spreadsheet
		return factory.getCellFeedUrl(spreadsheetKey, "default", "private", "full");
	}

}
