package test.google;

import java.io.IOException;
import java.net.URL;
import junit.framework.TestCase;
import com.google.gdata.client.spreadsheet.FeedURLFactory;
import com.google.gdata.client.spreadsheet.ListQuery;
import com.google.gdata.client.spreadsheet.SpreadsheetService;
import com.google.gdata.data.spreadsheet.ListEntry;
import com.google.gdata.data.spreadsheet.ListFeed;
import com.google.gdata.data.spreadsheet.SpreadsheetEntry;
import com.google.gdata.data.spreadsheet.SpreadsheetFeed;
import com.google.gdata.data.spreadsheet.WorksheetEntry;
import com.google.gdata.data.spreadsheet.WorksheetFeed;
import com.google.gdata.util.ServiceException;

public class GoogleFunction extends TestCase
{

	public static void main(String[] args) throws IOException, ServiceException
	{

		// Authenticate to Google Spreadsheets
		com.google.gdata.client.spreadsheet.SpreadsheetService service = new SpreadsheetService("innovent - birtDataSet - 1");
		service.setUserCredentials("info@innoventsolutions.com", "innovent2007");

		// get all SpreadSheets for the user
		FeedURLFactory factory = FeedURLFactory.getDefault();
		SpreadsheetFeed spreadsheet_feed;
		spreadsheet_feed = service.getFeed(factory.getSpreadsheetsFeedUrl(), SpreadsheetFeed.class);
		// Iterate over each SpreadSheet, get the worksheet feed.
		for (SpreadsheetEntry spreadsheet : spreadsheet_feed.getEntries())
		{
			System.out.println(spreadsheet.getTitle().getPlainText());
			WorksheetFeed worksheet_feed = service.getFeed(spreadsheet.getWorksheetFeedUrl(), WorksheetFeed.class);
			for (WorksheetEntry worksheet : worksheet_feed.getEntries())
			{
				System.out.println(" -" + worksheet.getTitle().getPlainText() + " " + worksheet.getListFeedUrl());
				showWorkSheet(service, worksheet.getListFeedUrl());
				System.out.println("\n-----------------------------------------------------------\n\n");
			}
		}
	}

	public static void showWorkSheet(SpreadsheetService service, URL feedUrl) throws IOException, ServiceException {
		ListQuery query = new ListQuery(feedUrl);
		
		// Use the ListFeed to work with the entire worksheet contents
		ListFeed feed = service.query(query, ListFeed.class);
		for (ListEntry listEntry : feed.getEntries()) {
			for (String tag : listEntry.getCustomElements().getTags()) {
				String rowName = listEntry.getTitle().getPlainText();
				String colName = tag;
				String cellValue =listEntry.getCustomElements().getValue(tag); 
				System.out.println("row(" + rowName + ") col( " + colName + ") "	+ cellValue );
			}
		}
	}
}
