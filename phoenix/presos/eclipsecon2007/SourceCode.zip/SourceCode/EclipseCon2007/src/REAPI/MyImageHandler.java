package REAPI;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.birt.report.engine.api.HTMLImageHandler;
import org.eclipse.birt.report.engine.api.IImage;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.IRenderOption;
import org.eclipse.birt.report.engine.api.HTMLRenderContext;

import org.eclipse.birt.report.engine.api.EngineException;


import org.eclipse.birt.report.engine.api.script.IReportContext;


import org.eclipse.birt.report.engine.i18n.MessageConstants;

/**
 * Default implementation for writing images in a form that is used in a
 * web-application.
 */
public class MyImageHandler extends HTMLImageHandler
{

	private String handlerId;
	private int count = 0;

	private static HashMap map = new HashMap( );

	/**
	 * dummy constructor
	 */
	public MyImageHandler( )
	{
		String codePart = Integer.toHexString( this.hashCode( ) );
		String timePart = Long.toHexString( System.currentTimeMillis( ) );
		handlerId = codePart + timePart;
	}

	public String onDesignImage( IImage image, Object context )
	{
		return handleImage( image, context, "design", true ); //$NON-NLS-1$
	}


	public String onDocImage( IImage image, Object context )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String onURLImage( IImage image, Object context )
	{
		assert ( image != null );
		String uri = image.getID( );
		if (uri.startsWith( "http:" ) || uri.startsWith( "https:" ))
		{
			return uri;
		}
		return handleImage( image, context, "uri", true ); //$NON-NLS-1$
	}


	public String onCustomImage( IImage image, Object context )
	{
		return handleImage( image, context, "custom", false ); //$NON-NLS-1$
	}

	/**
	 * returns a unique file name based on a directory and name prefix
	 * 
	 * @param imageDir
	 *            directory to store the image
	 * @param prefix
	 *            prefix for the file name
	 * @return a file name
	 */
	protected String createUniqueFileName( String imageDir, String prefix )
	{
		return createUniqueFileName( imageDir, prefix, null );
	}
	
	/**
	 * creates a unique tempoary file to store an image
	 * 
	 * @param imageDir
	 *            directory to put image into
	 * @param prefix
	 *            file name prefix
	 * @param postfix
	 *            file name postfix
	 * @return a Java File Object
	 */
	protected String createUniqueFileName( String imageDir, String prefix,
			String postfix )
	{
		File file = null;
		postfix = ( postfix == null ? "" : postfix );
		String uniCount = null;
		do
		{
			uniCount = genUniqueCount( );
			file = new File( imageDir + "/" + prefix + uniCount + postfix ); //$NON-NLS-1$
		} while ( file.exists( ) );
		
		return prefix + uniCount + postfix;
	}

	/**
	 * Generating unique string which contains following parts
	 * <li> the hashcode of the image handler
	 * <li> creation time of the image handler
	 * <li> image count created by the image handler
	 * @return return the unique count for filename
	 */
	synchronized private String genUniqueCount( )
	{
		count++;
		return handlerId + count;
	}


	public String onFileImage( IImage image, Object context )
	{
		return handleImage( image, context, "file", true ); //$NON-NLS-1$
	}

	/**
	 * handles an image report item and returns an image URL
	 * 
	 * @param image
	 *            represents the image design information
	 * @param context
	 *            context information
	 * @param prefix
	 *            image prefix in URL
	 * @param needMap
	 *            whether image map is needed
	 * @return URL for the image
	 */
	protected String handleImage( IImage image, Object context, String prefix,
			boolean needMap )
	{
		String mapID = null;
		if ( needMap )
		{
			mapID = getImageMapID( image );
			if ( map.containsKey( mapID ) )
			{
				return (String) map.get( mapID );
			}
		}
		String ret = null;
		//if ( context != null && ( context instanceof HTMLRenderOption ) )
		if ( context != null )
		{
			HTMLRenderContext myContext = (HTMLRenderContext) context;
			
			//HTMLRenderOption ro = (HTMLRenderOption)image.getRenderOption();
			String imageURL = myContext.getBaseImageURL( );
			String imageDir = myContext.getImageDirectory( );
			if ( imageURL == null || imageURL.length( ) == 0
					|| imageDir == null || imageDir.length( ) == 0 )
			{
				System.out.println("Error in image settings");
				return null;
			}

			String fileName;
			File file;
			String extension = image.getExtension( );
			if ( extension != null && extension.length( ) > 0 )
			{
				fileName = createUniqueFileName( imageDir, prefix, extension ); //$NON-NLS-1$
			}
			else
			{
				fileName = createUniqueFileName( imageDir, prefix );
			}
			file = new File( imageDir, fileName ); //$NON-NLS-1$
			try
			{
				image.writeImage( file );
			}
			catch ( IOException e )
			{
				e.printStackTrace();
			}
			// servlet mode
			if ( imageURL.indexOf( "?" ) > 0 ) //$NON-NLS-1$
			{
				ret = imageURL + fileName + "&specialid=test";
			}
			else if ( imageURL.endsWith( "/" ) ) //$NON-NLS-1$
			{
				ret = imageURL + fileName;
			}
			else
			{
				ret = imageURL + "/" + fileName; //$NON-NLS-1$
			}

			if ( needMap )
			{
				map.put( mapID, ret );
			}

		}
		else
		{
			ret = handleTempImage( image, prefix, needMap );
		}

		return ret;
	}

	protected String handleTempImage( IImage image, String prefix,
			boolean needMap )
	{
		try
		{

			File imageFile = File.createTempFile( prefix, ".img" );
			image.writeImage( imageFile );
			String fileName = imageFile.getAbsolutePath( ); 
			if ( needMap )
			{
				String mapID = getImageMapID( image );
				map.put( mapID, fileName );
			}
			return fileName;
		}
		catch ( IOException e )
		{
			e.printStackTrace();
		}
		return "unknow.img";
	}

	/**
	 * returns the unique identifier for the image
	 * 
	 * @param image
	 *            the image object
	 * @return the image id
	 */
	protected String getImageMapID( IImage image )
	{
		if ( image.getReportRunnable( ) != null )
		{
			return image.getReportRunnable( ).hashCode( ) + image.getID( );
		}
		return image.getID( );
	}


}