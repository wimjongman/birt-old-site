package org.eclipse.birt.examples.rcpengine;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.HashMap;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Plugin;



import org.eclipse.core.runtime.FileLocator;
import java.net.URL;
import java.io.*;


import org.eclipse.birt.core.framework.IPlatformContext;
//import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.core.framework.PlatformServletContext;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLRenderContext;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IRenderOption;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.osgi.framework.Bundle;



public class View extends ViewPart {
	public static final String ID = "org.eclipse.birt.examples.rcpengine.view";

	private TableViewer viewer;

	private transient Text reportLocation = null;

	private transient Button browseFolderButton = null;

	private Composite lParent;

	private GridData gridData;

	
	public static final String REPORT_FILE = "C:/test/testSampleDB.rptdesign";

	private Browser browser;

	private ProgressBar progressBar;

	/**
	 * The content provider class is responsible for providing objects to the
	 * view. It can wrap existing objects in adapters or simply return objects
	 * as-is. These objects may be sensitive to the current input of the view,
	 * or ignore it and always show the same content (like Task List, for
	 * example).
	 */
	class ViewContentProvider implements IStructuredContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) {
		}

		public void dispose() {
		}

		public Object[] getElements(Object parent) {
			return new String[] { "One", "Two", "Three" };
		}
	}

	class ViewLabelProvider extends LabelProvider implements
			ITableLabelProvider {
		public String getColumnText(Object obj, int index) {
			return getText(obj);
		}

		public Image getColumnImage(Object obj, int index) {
			return getImage(obj);
		}

		public Image getImage(Object obj) {
			return PlatformUI.getWorkbench().getSharedImages().getImage(
					ISharedImages.IMG_OBJ_ELEMENT);
		}
	}

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		lParent = parent;
		parent.setLayout(new GridLayout());
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		gridData = gd;
		Group reportGroup = new Group(parent, SWT.SHADOW_IN);
		reportGroup.setText("Select report:");
		GridLayout layout = new GridLayout(2, false);
		reportGroup.setLayout(layout);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		reportGroup.setLayoutData(gd);

		gd = new GridData();
		gd.horizontalSpan = 2;

		Label label = new Label(reportGroup, SWT.NONE);
		label.setText("Full Path:");

		label.setLayoutData(gd);

		reportLocation = new Text(reportGroup, SWT.BORDER);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		reportLocation.setLayoutData(gd);
		// setPageComplete(false);
		reportLocation.addModifyListener(new ModifyListener() {

			public void modifyText(ModifyEvent e) {
				//
			}

		});

		browseFolderButton = new Button(reportGroup, SWT.RIGHT);
		browseFolderButton.setText("..."); //$NON-NLS-1$
		browseFolderButton.addSelectionListener(new SelectionAdapter() {

			/*
			 * (non-Javadoc)
			 * 
			 * @see org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(reportLocation.getShell());
				String[] extension = { "*.rptdesign" };
				dialog.setFilterExtensions(extension);
				if (reportLocation.getText() != null
						&& reportLocation.getText().trim().length() > 0) {

					dialog.setFilterPath(reportLocation.getText());

				}

				String selectedLocation = dialog.open();
				if (selectedLocation != null) {
					reportLocation.setText(selectedLocation);
				}
			}

		});

		Button showReport = new Button(reportGroup, SWT.PUSH);
		showReport.setText("Run Report");

		showReport.addSelectionListener(new SelectionListener() {

			/*
			 * (non-Javadoc)
			 * 
			 * @see org.eclipse.swt.events.SelectionListener#widgetSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			public void widgetSelected(SelectionEvent e) {
				try {
					previewReport();
				} catch (Exception exp) {
					exp.printStackTrace();
				}
				// addReportParameters(lParent, gridData);
				// openReportRunner();
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see org.eclipse.swt.events.SelectionListener#widgetDefaultSelected(org.eclipse.swt.events.SelectionEvent)
			 */
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		browser = new Browser(parent, SWT.NONE);
		gd = new GridData(GridData.FILL_BOTH);
		gd.horizontalSpan = 2;
		browser.setLayoutData(gd);

	}

	private void previewReport() throws EngineException {

		EngineConfig config = new EngineConfig();
		
		// Create the report engine
		IReportEngineFactory factory = (IReportEngineFactory) org.eclipse.birt.core.framework.Platform
				.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
		IReportEngine engine = factory.createReportEngine( config );
		
		IReportRunnable design = null;
		try {
			// Open a report design - use design to modify design, retrieve
			// embedded images etc.
			String report = reportLocation.getText();
			
			   //Bundle bundle = org.eclipse.core.runtime.Platform.getBundle("org.eclipse.birt.examples.rcpengine");
			   //Path path = new Path("reports/TopNPercent.rptdesign");
			   //URL fileURL = FileLocator.find(bundle, path, null);
			   //InputStream in = fileURL.openStream();
			
			System.setProperty( EngineConstants.WEBAPP_CLASSPATH_KEY,
			"c:/myclasses" );	

			FileInputStream fs = new FileInputStream(report);
			design = engine.openReportDesign(fs);
			//design = engine.openReportDesign(in);
			IRunAndRenderTask task = engine.createRunAndRenderTask(design);

					
			// Set rendering options - such as file or stream output,
			// output format, whether it is embeddable, etc		
			HTMLRenderOption options;
			options = new HTMLRenderOption( );
			options.setImageDirectory("c:/temp/images");
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			options.setOutputStream(bos);
			options.setOutputFormat("html");

			
			task.setRenderOption(options);

			// run the report and destroy the engine
			task.run();
			task.close();
			
			//set Browser text accordingly
			browser.setText(bos.toString());
			engine.destroy();
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {

	}
}