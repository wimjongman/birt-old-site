package DEAPI;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;


import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.model.api.CellHandle;
import org.eclipse.birt.report.model.api.DataItemHandle;
import org.eclipse.birt.report.model.api.DesignConfig;
import org.eclipse.birt.report.model.api.ElementFactory;
import org.eclipse.birt.report.model.api.IDesignEngine;
import org.eclipse.birt.report.model.api.IDesignEngineFactory;
import org.eclipse.birt.report.model.api.LabelHandle;
import org.eclipse.birt.report.model.api.ImageHandle;
import org.eclipse.birt.report.model.api.ActionHandle;
import org.eclipse.birt.report.model.api.ReportElementHandle;


import org.eclipse.birt.report.model.api.OdaDataSetHandle;
import org.eclipse.birt.report.model.api.OdaDataSourceHandle;
import org.eclipse.birt.report.model.api.PropertyHandle;
import org.eclipse.birt.report.model.api.ReportDesignHandle;
import org.eclipse.birt.report.model.api.RowHandle;
import org.eclipse.birt.report.model.api.SessionHandle;
import org.eclipse.birt.report.model.api.StructureFactory;
import org.eclipse.birt.report.model.api.TableHandle;
import org.eclipse.birt.report.model.api.activity.SemanticException;
import org.eclipse.birt.report.model.api.elements.structures.ComputedColumn;
import org.eclipse.birt.report.model.api.PropertyHandle;
import org.eclipse.birt.report.model.elements.ReportItem;

import org.eclipse.birt.report.model.api.elements.structures.EmbeddedImage;

import org.eclipse.birt.report.model.elements.Style;
import org.eclipse.birt.report.model.api.StyleHandle;

import org.eclipse.birt.report.model.api.elements.structures.MapRule;
import org.eclipse.birt.report.model.api.elements.structures.HideRule;

import org.eclipse.birt.report.model.api.elements.DesignChoiceConstants;

import org.eclipse.birt.report.model.api.elements.structures.HighlightRule;

import org.eclipse.birt.report.model.api.elements.structures.SortKey;
import org.eclipse.birt.report.model.api.SortKeyHandle;

import org.eclipse.birt.report.model.api.elements.structures.FilterCondition;
import org.eclipse.birt.report.model.api.elements.structures.Action;


import com.ibm.icu.util.ULocale;

/**
 * Simple BIRT Design Engine API (DEAPI) demo.
 */

public class StructFactoryTest
{
	ReportDesignHandle designHandle = null;
	ElementFactory designFactory = null;
	StructureFactory structFactory = null;	

	public static void main( String[] args )
	{
		try
		{
			StructFactoryTest de = new StructFactoryTest();		
			de.buildReport();
		}
		catch ( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch ( SemanticException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void buildDataSource( ) throws SemanticException
	{

		OdaDataSourceHandle dsHandle = designFactory.newOdaDataSource(
				"Data Source", "org.eclipse.birt.report.data.oda.jdbc" );
		dsHandle.setProperty( "odaDriverClass",
				"org.eclipse.birt.report.data.oda.sampledb.Driver" );
		dsHandle.setProperty( "odaURL", "jdbc:classicmodels:sampledb" );
		dsHandle.setProperty( "odaUser", "ClassicModels" );
		dsHandle.setProperty( "odaPassword", "" );

		designHandle.getDataSources( ).add( dsHandle );

	}

	void buildDataSet( ) throws SemanticException
	{

		OdaDataSetHandle dsHandle = designFactory.newOdaDataSet( "ds",
		"org.eclipse.birt.report.data.oda.jdbc.JdbcSelectDataSet" );
		dsHandle.setDataSource( "Data Source" );
		String qry = "Select * from customers";

		dsHandle.setQueryText( qry );



		try{
			FilterCondition fc = structFactory.createFilterCond();
			fc.setExpr("dataSetRow[\"COUNTRY\"]");
			fc.setOperator(DesignChoiceConstants.MAP_OPERATOR_EQ);
			fc.setValue1("'USA'");

			PropertyHandle ph = dsHandle.getPropertyHandle(OdaDataSetHandle.FILTER_PROP);
			ph.addItem(fc);
		}catch (Exception e){
			e.printStackTrace();
		}

		designHandle.getDataSets( ).add( dsHandle );


	}
	void addMapRule(TableHandle th){
		try{
		MapRule mr = structFactory.createMapRule();
		mr.setTestExpression("row[\"CustomerCreditLimit\"]");
		mr.setOperator(DesignChoiceConstants.MAP_OPERATOR_EQ);
		mr.setValue1("0");
		mr.setDisplay("N/A");

		PropertyHandle ph = th.getPropertyHandle(StyleHandle.MAP_RULES_PROP);
		ph.addItem(mr);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	void addVisRule(ReportElementHandle rh){
		try{
		HideRule hr = structFactory.createHideRule();
		hr.setFormat("pdf");
		hr.setExpression("true");

		PropertyHandle ph = rh.getPropertyHandle(ReportItem.VISIBILITY_PROP);
		ph.addItem(hr);
		}catch (Exception e){
			e.printStackTrace();
		}
	}	
	void addBottomBorder(ReportElementHandle rh){
		try{


		rh.setProperty(StyleHandle.BORDER_BOTTOM_COLOR_PROP, "#000000");
		rh.setProperty(StyleHandle.BORDER_BOTTOM_STYLE_PROP, "solid");
		rh.setProperty(StyleHandle.BORDER_BOTTOM_WIDTH_PROP, "2px");
		
		}catch (Exception e){
			e.printStackTrace();
		}
	}		
	void addHighLightRule(RowHandle th){
		try{
		HighlightRule hr = structFactory.createHighlightRule();
		
		hr.setOperator(DesignChoiceConstants.MAP_OPERATOR_GT);
		hr.setTestExpression("row[\"CustomerCreditLimit\"]");
		hr.setValue1("100000");
		hr.setProperty(HighlightRule.BACKGROUND_COLOR_MEMBER, "blue");
		
		PropertyHandle ph = th.getPropertyHandle(StyleHandle.HIGHLIGHT_RULES_PROP);
		
		ph.addItem(hr);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	void addSortKey(TableHandle th){
		try{
		SortKey sk = structFactory.createSortKey();
		sk.setKey("row[\"CustomerName\"]");
		sk.setDirection(DesignChoiceConstants.SORT_DIRECTION_ASC);

		PropertyHandle ph = th.getPropertyHandle(TableHandle.SORT_PROP);
		ph.addItem(sk);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	void modSortKey(TableHandle th){
		try{
		SortKeyHandle sk;
		PropertyHandle ph = th.getPropertyHandle(TableHandle.SORT_PROP);
		//get number or iterate
		sk = (SortKeyHandle)ph.get(0);
		sk.setDirection(DesignChoiceConstants.SORT_DIRECTION_DESC);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
		
	
	
	void addFilterCondition(TableHandle th){
		try{
		FilterCondition fc = structFactory.createFilterCond();
		fc.setExpr("row[\"CustomerCountry\"]");
		fc.setOperator(DesignChoiceConstants.MAP_OPERATOR_EQ);
		fc.setValue1("'USA'");
		
		PropertyHandle ph = th.getPropertyHandle(TableHandle.FILTER_PROP);
		ph.addItem(fc);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	void addHyperlink(LabelHandle lh){
		try{
		Action ac = structFactory.createAction();
		
		ActionHandle actionHandle = lh.setAction( ac );		
		actionHandle.setURI("'http://www.google.com'");
		actionHandle.setLinkType(DesignChoiceConstants.ACTION_LINK_TYPE_HYPERLINK);
		
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	void addImage(){
		try{
		EmbeddedImage image = structFactory.createEmbeddedImage( );
		image.setType( DesignChoiceConstants.IMAGE_TYPE_IMAGE_JPEG );
		image.setData( load( "logo3.jpg" ) ); 
		image.setName( "mylogo" ); 
		
		designHandle.addImage( image );
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	public byte[] load( String fileName ) throws IOException
	{
		InputStream is = null;

		is = new BufferedInputStream( this.getClass( ).getResourceAsStream(
				fileName ) );
		byte data[] = null;
		if ( is != null )
		{
			try
			{
				data = new byte[is.available( )];
				is.read( data );
			}
			catch ( IOException e1 )
			{
				throw e1;
			}
		}
		return data;
	}	
	
	void buildReport() throws IOException, SemanticException
	{

		DesignConfig config = new DesignConfig( );
		config.setBIRTHome("C:/birt/birt-runtime-2.2m5/birt-runtime-2_2_0/ReportEngine");
		IDesignEngine engine = null;
		try{


			Platform.startup( config );
			IDesignEngineFactory factory = (IDesignEngineFactory) Platform
			.createFactoryObject( IDesignEngineFactory.EXTENSION_DESIGN_ENGINE_FACTORY );
			engine = factory.createDesignEngine( config );

		}catch( Exception ex){
			ex.printStackTrace();
		}


		SessionHandle session = engine.newSessionHandle( ULocale.ENGLISH ) ;

		ReportDesignHandle design = null;

	

		try{
			//open a design or a template
			designHandle = session.createDesign();

			designFactory = designHandle.getElementFactory( );

			buildDataSource();
			buildDataSet();

			TableHandle table = designFactory.newTableItem( "table", 3 );
			table.setWidth( "100%" );
			table.setDataSet( designHandle.findDataSet( "ds" ) );

			 
			PropertyHandle computedSet = table.getColumnBindings( ); 
			ComputedColumn  cs1, cs2, cs3, cs4;

			
			cs1 = StructureFactory.createComputedColumn();
			cs1.setName("CustomerName");
			cs1.setExpression("dataSetRow[\"CUSTOMERNAME\"]");
			computedSet.addItem(cs1);		
			cs2 = StructureFactory.createComputedColumn();
			cs2.setName("CustomerCity");
			cs2.setExpression("dataSetRow[\"CITY\"]");
			computedSet.addItem(cs2);
			cs3 = StructureFactory.createComputedColumn();
			cs3.setName("CustomerCountry");
			cs3.setExpression("dataSetRow[\"COUNTRY\"]");
			computedSet.addItem(cs3);
			cs4 = StructureFactory.createComputedColumn();
			cs4.setName("CustomerCreditLimit");
			cs4.setExpression("dataSetRow[\"CREDITLIMIT\"]");
			computedSet.addItem(cs4);
		
			
			// table header
			RowHandle tableheader = (RowHandle) table.getHeader( ).get( 0 );

			
	
			LabelHandle label1 = designFactory.newLabel("Label1" );	
		    addBottomBorder(label1);
			label1.setText("Customer");
			CellHandle cell = (CellHandle) tableheader.getCells( ).get( 0 );
			cell.getContent( ).add( label1 );
			LabelHandle label2 = designFactory.newLabel("Label2" );	
			label2.setText("City");
			cell = (CellHandle) tableheader.getCells( ).get( 1 );
			cell.getContent( ).add( label2 );
			LabelHandle label3 = designFactory.newLabel("Label3" );	
			label3.setText("Credit Limit");
			cell = (CellHandle) tableheader.getCells( ).get( 2 );
			cell.getContent( ).add( label3 );
									
	
			// table detail
			RowHandle tabledetail = (RowHandle) table.getDetail( ).get( 0 );

			cell = (CellHandle) tabledetail.getCells( ).get( 0 );
			DataItemHandle data = designFactory.newDataItem( "data1" );
			data.setResultSetColumn("CustomerName");
			cell.getContent( ).add( data );
			cell = (CellHandle) tabledetail.getCells( ).get( 1 );
			data = designFactory.newDataItem( "data2" );
			data.setResultSetColumn("CustomerCity");
			cell.getContent( ).add( data );
			cell = (CellHandle) tabledetail.getCells( ).get( 2 );
			data = designFactory.newDataItem( "data3" );
			data.setResultSetColumn("CustomerCreditLimit");
			cell.getContent( ).add( data );

			addHyperlink(label1);
			addMapRule(table);
			addHighLightRule(tabledetail);
			addSortKey(table);
			modSortKey(table);
			addFilterCondition(table);
			addImage();

			RowHandle tablefooter = (RowHandle) table.getFooter().get( 0 );
			cell = (CellHandle) tablefooter.getCells( ).get( 0 );
			
			ImageHandle image1 = designFactory.newImage( "Logo" );
			
			image1.setImageName( "mylogo" );
			addVisRule( image1 );
			cell.getContent( ).add( image1 );
			
			designHandle.getBody( ).add( table );

			// Save the design and close it.

			designHandle.saveAs("output/desample/structfactorytest.rptdesign" );
			designHandle.close( );
			Platform.shutdown();
			System.out.println("Finished");
		}catch (Exception e){
			e.printStackTrace();
		}		

	}
}

