package REAPI;

public class DummyClass {
public String getString(){
	return( "This is a test");
}
}
