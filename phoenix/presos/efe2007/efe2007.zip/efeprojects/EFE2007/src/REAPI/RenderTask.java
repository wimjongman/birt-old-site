package REAPI;



import java.util.HashMap;
import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLActionHandler;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.PDFRenderOption;
import org.eclipse.birt.report.engine.api.HTMLServerImageHandler;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IReportDocument;

import org.eclipse.birt.report.engine.api.IRenderTask;
import org.eclipse.birt.report.engine.api.IRenderOption;
import org.eclipse.birt.report.engine.api.RenderOption;
import org.eclipse.birt.report.engine.api.IHTMLRenderOption;
import org.eclipse.birt.report.engine.api.IPDFRenderOption;





public class RenderTask {

	public void runReport() throws EngineException
	{

		IReportEngine engine=null;
		EngineConfig config = null;

		try{
	
			config = new EngineConfig( );			
			config.setBIRTHome("C:/birt/birt-runtime-2.2M5/birt-runtime-2_2_0/ReportEngine");
			config.setLogConfig(null, Level.FINE);
			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
		}catch( Exception ex){
			ex.printStackTrace();
		}

		IReportDocument document = null;
		//Open the report design
		document = engine.openReportDocument("output/resample/customers.rptdocument"); 

		IRenderOption options = new RenderOption();
		
		options.setOutputFormat("html");
		options.setOutputFileName("output/resample/customers.html");
	
			
		if( options.getOutputFormat().equalsIgnoreCase("html")){
			HTMLRenderOption htmlOptions = new HTMLRenderOption( options);
			htmlOptions.setImageDirectory("output/image");
			htmlOptions.setHtmlPagination(false);
			
			//htmlOptions.setHtmlRtLFlag(true);
			//htmlOptions.setEmbeddable(true);
		}else{
			
			PDFRenderOption pdfOptions = new PDFRenderOption( options );
			//pdfOptions.setOption( IPDFRenderOption.FIT_TO_PAGE, new Boolean(true) );
			//pdfOptions.setOption( IPDFRenderOption.PAGEBREAK_PAGINATION_ONLY, new Boolean(true) );

		}
		options.setActionHandler(new MyActionHandler());
		
		IRenderTask task = engine.createRenderTask(document); 		
		task.setRenderOption(options);
		
		
		//task.setPageRange("1,5-7");
		task.render();
				
		



		task.close();
		engine.destroy();
		Platform.shutdown();
		System.out.println("Finished");
	}	


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{

			RenderTask ex = new RenderTask( );
			ex.runReport();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}

	
}


