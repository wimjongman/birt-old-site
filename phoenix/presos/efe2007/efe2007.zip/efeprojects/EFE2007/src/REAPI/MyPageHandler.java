package REAPI;
import org.eclipse.birt.report.engine.api.IPageHandler;
import org.eclipse.birt.report.engine.api.IReportDocumentInfo;;

public class MyPageHandler implements IPageHandler
{
	public void onPage( int pageNumber, boolean checkpoint, IReportDocumentInfo doc){
		//Checkpoint is set true on page 1, 10, 50 and then multiples of 100 and end of report;
		if( checkpoint == true){

		System.out.println("Page " + pageNumber + " is Complete");
		//can use do to open the report document and render
		}
	}
}
