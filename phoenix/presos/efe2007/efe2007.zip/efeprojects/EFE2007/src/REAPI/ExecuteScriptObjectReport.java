package REAPI;



import java.util.HashMap;
import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLActionHandler;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.HTMLServerImageHandler;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import org.eclipse.birt.report.engine.api.RenderOption;




public class ExecuteScriptObjectReport {

	public void runReport() throws EngineException
	{

		IReportEngine engine=null;
		EngineConfig config = null;
		//config.setRourcePath()

		try{

			DummyClass dl = new DummyClass();
			

			System.setProperty( EngineConstants.WEBAPP_CLASSPATH_KEY,
					"c:/myclasses" );		
			System.setProperty("java.io.tmpdir", "c:/temp");
			//Configure the Engine and start the Platform
			config = new EngineConfig( );
			HashMap hm = config.getAppContext();
			hm.put( "dummy", dl);
			config.setAppContext(hm);
			
			config.setBIRTHome("C:/birt/birt-runtime-2.2m5/birt-runtime-2_2_0/ReportEngine");

			config.setLogConfig(null, Level.FINE);

			//config.setResourcePath("c:/mybirtresources/");
			config.setTempDir("c:/temp");
			config.setMaxRowsPerQuery(2000);



			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
			engine.changeLogLevel( Level.FINEST );

		}catch( Exception ex){
			ex.printStackTrace();
		}

		//Configure the emitter to handle actions and images

		//replace this with
		//HTMLEmitterConfig emitterConfig = new HTMLEmitterConfig( );
		//emitterConfig.setActionHandler( new HTMLActionHandler( ) );
		//HTMLServerImageHandler imageHandler = new HTMLServerImageHandler( );
		//emitterConfig.setImageHandler( imageHandler );
		//config.getEmitterConfigs( ).put( "html", emitterConfig ); //$NON-NLS-1$

		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		//this
		//HTMLServerImageHandler used for web deployment
		//HTMLCompleteImageHandler used for file base deployment
		HTMLServerImageHandler imageHandler = new HTMLServerImageHandler( );

		RenderOption ro = new RenderOption();
		ro.setImageHandler(imageHandler);

		//Write your own drill through hyperlink interpeter
		ro.setActionHandler(new HTMLActionHandler());
		//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




		IReportRunnable design = null;

		//Open the report design
		//design = engine.openReportDesign("C:/work/ReportEngineReportExamples/TopSellingProducts.rptdesign"); 
		design = engine.openReportDesign("Reports/DummyObject.rptdesign");
		
		

		//change data source/set property
		//ReportDesignHandle report = (ReportDesignHandle) design.getDesignHandle( );
		//OdaDataSourceHandle dataSourceHandle = (OdaDataSourceHandle) report.findDataSource( "Data Source" );
		//odaDriverClass
		//odaPassword
		//odaUser
		//String odaurl = dataSourceHandle.getStringProperty( "odaURL" );



		//Create task to run and render the report,
		IRunAndRenderTask task = engine.createRunAndRenderTask(design); 


		//Set rendering options - such as file or stream output, 
		//output format, whether it is embeddable, etc
		HTMLRenderOption options = new HTMLRenderOption();

		//Remove HTML and Body tags
		//options.setEmbeddable(true);

		//Set ouptut location
		options.setOutputFileName("output/resample/test.html");

		//options.setOutputStream(response.getOutputStream());

		//Set output format
		options.setOutputFormat("html");
		task.setRenderOption(options);

		//run the report and destroy the engine
		//Note - If the program stays resident do not shutdown the Platform or the Engine
		task.run();


		task.close();
		engine.destroy();
		Platform.shutdown();
		System.out.println("Finished");
	}	


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{

			ExecuteScriptObjectReport ex = new ExecuteScriptObjectReport( );
			ex.runReport();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
}


