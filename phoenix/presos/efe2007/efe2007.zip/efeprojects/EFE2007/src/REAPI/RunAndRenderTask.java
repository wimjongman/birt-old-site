package REAPI;



import java.util.HashMap;
import java.util.logging.Level;

import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineConstants;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLActionHandler;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.HTMLServerImageHandler;
import org.eclipse.birt.report.engine.api.HTMLCompleteImageHandler;

import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import org.eclipse.birt.report.engine.api.RenderOption;




public class RunAndRenderTask {

	public void runReport() throws EngineException
	{

		IReportEngine engine=null;
		EngineConfig config = null;

		try{
			System.setProperty("java.io.tmpdir", "c:/temp/test/testsampledb");	
			config = new EngineConfig( );			
			config.setBIRTHome("C:/birt/birt-runtime-2.2m5/birt-runtime-2_2_0/ReportEngine");
			config.setLogConfig("c:/temp/test", Level.ALL);
			Platform.startup( config );
			IReportEngineFactory factory = (IReportEngineFactory) Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			engine = factory.createReportEngine( config );
		

		IReportRunnable design = null;
		//Open the report design
		design = engine.openReportDesign("Reports/TopNPercent.rptdesign"); 
	


		//Create task to run and render the report,
		IRunAndRenderTask task = engine.createRunAndRenderTask(design); 		
		task.setParameterValue("Top Percentage", (new Integer(3)));;
		task.setParameterValue("Top Count", (new Integer(5)));
		task.validateParameters();
				
		HTMLRenderOption options = new HTMLRenderOption();		
		options.setOutputFileName("output/resample/TopNPercent.html");
		options.setOutputFormat("html");
		
		//options.setImageDirectory("images");
		
		//ImageHandlerTest
		//options.setImageHandler(new MyImageHandler());
		//options.setImageHandler(new HTMLServerImageHandler());
		options.setImageHandler(new HTMLCompleteImageHandler());
		options.setBaseImageURL("http://localhost/imageGetter?");
		task.setRenderOption(options);

		
		
		CancelReport cancelThread = new CancelReport( "cancelReport", task);
		cancelThread.start();
		long beginTime = System.currentTimeMillis(); 
		task.run();
		long endTime = System.currentTimeMillis();
		long timeSpan = endTime - beginTime;
		System.out.println("Report Runtime: " + timeSpan);
		int teststatus = task.getStatus();
		if( teststatus == 4){
			System.out.println("Report was cancelled");
		}
		task.close();
		

		//Create task to run and render the report,
		task = engine.createRunAndRenderTask(design); 		
		task.setParameterValue("Top Percentage", (new Integer(3)));
		task.setParameterValue("Top Count", (new Integer(5)));
		task.validateParameters();
		task.setRenderOption(options);		
		
		
		beginTime = System.currentTimeMillis(); 
		task.run();
		endTime = System.currentTimeMillis();
		timeSpan = endTime - beginTime;
		System.out.println("Report Runtime: " + timeSpan);
		teststatus = task.getStatus();
		if( teststatus == 2){
			System.out.println("Report Completed");
		}		
		
		task.close();
		
		
		
		engine.shutdown();
		engine.destroy();
		}catch( Exception ex){
			ex.printStackTrace();
		}		
		finally
		{
			Platform.shutdown( );
			System.out.println("Finished");
		}
		
	}	


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{

			RunAndRenderTask ex = new RunAndRenderTask( );
			ex.runReport();

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	private class CancelReport extends Thread
	{
		private IRunAndRenderTask rTask;
		public CancelReport( String threadName, IRunAndRenderTask task){
			super(threadName);
			rTask = task;
			
		}
		public void run()
		{
			try{
				Thread.currentThread().sleep( 100 );
				rTask.cancel();
				System.out.println("######Report Cancelled#######");
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	
}


