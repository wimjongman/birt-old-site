package REAPI;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.logging.Logger;

import org.eclipse.birt.report.engine.api.HTMLRenderContext;
import org.eclipse.birt.report.engine.api.IAction;
import org.eclipse.birt.report.engine.api.EngineConstants;

import org.eclipse.birt.report.engine.api.script.IReportContext;

import org.eclipse.birt.report.engine.api.IHTMLActionHandler;
import java.util.Map;



/**
 * Defines a default action handler for HTML output format
 */
public class MyActionHandler implements IHTMLActionHandler
{

	public String getURL( IAction actionDefn, IReportContext context )
	{
		Object renderContext = getRenderContext( context );
		return getURL( actionDefn, renderContext );
	}

	public String getURL( IAction actionDefn, Object context )
	{
		if ( actionDefn == null )
		{
			return null;
		}
		String url = null;
		switch ( actionDefn.getType( ) )
		{
			case IAction.ACTION_BOOKMARK :
				if ( actionDefn.getActionString( ) != null )
				{
					url = "#" + actionDefn.getActionString( );
				}
				break;
			case IAction.ACTION_HYPERLINK :
				//url = actionDefn.getActionString( );
				url = "Http://www.google.com";
				break;
			case IAction.ACTION_DRILLTHROUGH :
				url = buildDrillAction( actionDefn, context );
				break;
			default :
		}
		return url;
	}

	/**
	 * builds URL for drillthrough action
	 * 
	 * @param action
	 *            instance of the IAction instance
	 * @param context
	 *            the context for building the action string
	 * @return a URL
	 */
	protected String buildDrillAction( IAction action, Object context )
	{
		String baseURL = null;
		if ( context != null && context instanceof HTMLRenderContext )
		{
			baseURL = ( (HTMLRenderContext) context ).getBaseURL( );
		}

		StringBuffer link = new StringBuffer( );
		link.append(baseURL);
		String reportName = action.getReportName( );
		String test = reportName.replace(".rptdesign", ".html");
		link.append(test);
		link.append("#");
		String bmk = action.getBookmark( );
		link.append(bmk);

		return link.toString( );
	}

	protected void appendReportDesignName( StringBuffer buffer,
			String reportName )
	{
		//buffer.append( "?__report=" ); //$NON-NLS-1$
		try
		{
			buffer.append( URLEncoder.encode( reportName, "UTF-8" ) ); //$NON-NLS-1$
		}
		catch ( UnsupportedEncodingException e1 )
		{
			// It should not happen. Does nothing
		}
	}

	protected void appendFormat( StringBuffer buffer, String format )
	{
		if ( format != null && format.length( ) > 0 )
		{
			buffer.append( "&__format=" + format );//$NON-NLS-1$
		}
	}

	protected void appendParamter( StringBuffer buffer, String key,
			Object valueObj )
	{
		if ( valueObj != null )
		{
			try
			{
				key = URLEncoder.encode( key, "UTF-8" );
				String value = valueObj.toString( );
				value = URLEncoder.encode( value, "UTF-8" );
				buffer.append( "&" );
				buffer.append( key );
				buffer.append( "=" );
				buffer.append( value );
			}
			catch ( UnsupportedEncodingException e )
			{
				// Does nothing
			}
		}
	}

	protected void appendBookmarkAsParamter( StringBuffer buffer,
			String bookmark )
	{
		try
		{
			if ( bookmark != null && bookmark.length( ) != 0 )
			{
				bookmark = URLEncoder.encode( bookmark, "UTF-8" );
				buffer.append( "&__bookmark=" );//$NON-NLS-1$
				buffer.append( bookmark );
			}
		}
		catch ( UnsupportedEncodingException e )
		{

		}
	}

	protected void appendBookmark( StringBuffer buffer, String bookmark )
	{
		try
		{
			if ( bookmark != null && bookmark.length( ) != 0 )
			{
				bookmark = URLEncoder.encode( bookmark, "UTF-8" );
				buffer.append( "#" );//$NON-NLS-1$
				buffer.append( bookmark );
			}
		}
		catch ( UnsupportedEncodingException e )
		{
		}
	}



protected Object getRenderContext( IReportContext context )
{
	Map appContext = context.getAppContext( );
	if ( appContext != null )
	{
		String renderContextKey = EngineConstants.APPCONTEXT_HTML_RENDER_CONTEXT;
		String format = context.getOutputFormat( );
		if ( "pdf".equalsIgnoreCase( format ) )
		{
			renderContextKey = EngineConstants.APPCONTEXT_PDF_RENDER_CONTEXT;
		}
		return appContext.get( renderContextKey );
	}
	return null;
}
}