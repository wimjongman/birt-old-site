

import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;

import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.IReportEngine;
import javax.servlet.*;
import org.eclipse.birt.core.framework.PlatformServletContext;
import org.eclipse.birt.core.framework.IPlatformContext;
import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.core.exception.BirtException;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.ReportEngine;
import org.eclipse.birt.report.model.api.IDesignEngineFactory;
import org.eclipse.birt.report.model.api.IDesignEngine;


public class BirtEngine {

	private static IReportEngine birtEngine = null;
	private static IDesignEngine birtDesignEngine = null;
	//private static IMyFactory myFactory = null;

	private static Properties configProps = new Properties();

	private final static String configFile = "BirtConfig.properties";
	
	

	public static synchronized void initBirtConfig() {
		loadEngineProps();
	}

	public static synchronized IReportEngine getBirtEngine(ServletContext sc) {
		if (birtEngine == null) 
		{
			System.setProperty("java.io.tmpdir", "c:/temp/pp");
			EngineConfig config = new EngineConfig();
			if( configProps != null){
				String logLevel = configProps.getProperty("logLevel");
				Level level = Level.OFF;
				if ("SEVERE".equalsIgnoreCase(logLevel)) 
				{
					level = Level.SEVERE;
				} else if ("WARNING".equalsIgnoreCase(logLevel))
				{
					level = Level.WARNING;
				} else if ("INFO".equalsIgnoreCase(logLevel)) 
				{
					level = Level.INFO;
				} else if ("CONFIG".equalsIgnoreCase(logLevel))
				{
					level = Level.CONFIG;
				} else if ("FINE".equalsIgnoreCase(logLevel)) 
				{
					level = Level.FINE;
				} else if ("FINER".equalsIgnoreCase(logLevel)) 
				{
					level = Level.FINER;
				} else if ("FINEST".equalsIgnoreCase(logLevel)) 
				{
					level = Level.FINEST;
				} else if ("OFF".equalsIgnoreCase(logLevel)) 
				{
					level = Level.OFF;
				}

				config.setLogConfig(configProps.getProperty("logDirectory"), level);
			}

			config.setBIRTHome("");
			IPlatformContext context = new PlatformServletContext( sc );
			config.setPlatformContext( context );

		
			//Create the report engine
			//birtEngine = new ReportEngine( config );
			//ReportEngine engine = new ReportEngine( null );
			
			
			try
			{
				Platform.startup( config );
				
		}
			catch ( Exception e )
			{
				e.printStackTrace( );
			}

			Object factory = Platform
			.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
			
			if ( factory instanceof IReportEngineFactory ){
				System.out.println("XYZMatch");
			}

			System.out.println("EngineFactory = " + factory.getClass().toString());
			System.out.println( factory.getClass().getClassLoader().toString());
			System.out.println( "Ireportengine interface " + IReportEngineFactory.class.getClassLoader().toString());
			
			IReportEngineFactory mfactory = (IReportEngineFactory) factory;
			ClassLoader cl = IReportEngineFactory.class.getClassLoader();
			
			
			birtEngine = mfactory.createReportEngine( config );


		

		}
		return birtEngine;
	}

	public static synchronized void destroyBirtEngine() {
		if (birtEngine == null) {
			return;
		}		
		birtEngine.shutdown();
		Platform.shutdown();
		birtEngine = null;
	}

	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	private static void loadEngineProps() {
		try {
			//Config File must be in classpath
			ClassLoader cl = Thread.currentThread ().getContextClassLoader();
			InputStream in = null;
			in = cl.getResourceAsStream (configFile);
			configProps.load(in);
			in.close();


		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
